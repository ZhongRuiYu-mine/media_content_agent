# coding: utf-8
"""_probe_workbench_api.py — 三栏工作台前端的 API 形状探针(开发期自查, 可重复运行)。

用途: 在不启动 uvicorn 的前提下, 用 TestClient 按前端将要走的顺序调一遍
`/api/content/*`, 把每步返回的键结构打印出来, 供前端对齐字段(不写任何生产数据:
STORAGE_BASE_DIR / CONTENT_VERSIONS_DIR / TOPIC_BANK_DIR / REPORT_DIR 全指向临时目录)。

零 LLM: LLM_GATE_MODE=auto_deny。
"""
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["EMBEDDING_OFF"] = "1"
os.environ["LLM_GATE_MODE"] = "auto_deny"
os.environ["AUTH_ENABLED"] = "0"
os.environ["TOPIC_STORE_BACKEND"] = "file"
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TMP = os.path.join(_HERE, "data", "_probe_workbench_tmp")
shutil.rmtree(_TMP, ignore_errors=True)
os.environ["STORAGE_BASE_DIR"] = os.path.join(_TMP, "graphs")
os.environ["CONTENT_VERSIONS_DIR"] = os.path.join(_TMP, "versions")
os.environ["TOPIC_BANK_DIR"] = os.path.join(_TMP, "topics")
os.environ["REPORT_DIR"] = os.path.join(_TMP, "reports")
os.environ["RESOLUTION_DIR"] = os.path.join(_TMP, "resolutions")  # 用户裁决也要隔离

from starlette.testclient import TestClient  # noqa: E402

import server  # noqa: E402

C = TestClient(server.app)
CLUB = "demo_club"
OUT = {}


def show(name, obj, depth=2):
    """打印结构(键 + 类型), 不打印全文, 避免刷屏。"""
    print("=" * 70)
    print("[%s]" % name)
    print(json.dumps(_shape(obj, depth), ensure_ascii=False, indent=1)[:2600])
    OUT[name] = obj


def _shape(o, depth):
    if depth <= 0:
        if isinstance(o, list):
            return "[...]"
        if isinstance(o, dict):
            return "{...}"
        return o
    if isinstance(o, dict):
        return {k: _shape(v, depth - 1) for k, v in list(o.items())[:24]}
    if isinstance(o, list):
        return [_shape(o[0], depth - 1)] if o else []
    if isinstance(o, str):
        return o[:90]
    return o


def main():
    r = C.post("/api/content/seed_demo", json={"club_id": CLUB})
    print("seed:", r.status_code, r.json().get("count"))
    show("state", C.get("/api/content/state", params={"club_id": CLUB}).json())
    show("gaps", C.get("/api/content/gaps", params={"club_id": CLUB}).json())
    show("checklist", C.get("/api/content/checklist", params={"club_id": CLUB}).json())
    show("topics_scan", C.get("/api/content/topics",
                             params={"club_id": CLUB, "scan": 1}).json())
    show("topics_bank", C.get("/api/content/topics",
                              params={"club_id": CLUB, "scan": 0}).json())
    d = C.post("/api/content/draft", json={"club_id": CLUB, "max_segments": 6}).json()
    show("draft", d)
    v = C.post("/api/content/verify", json={"club_id": CLUB}).json()
    show("verify", v)
    show("platforms", C.post("/api/content/platforms", json={"club_id": CLUB}).json())
    show("platforms_force", C.post("/api/content/platforms",
                                   json={"club_id": CLUB, "force": True}).json())
    show("versions", C.get("/api/content/versions", params={"club_id": CLUB}).json())
    # 新版前端的三块: 积木流 → 三渠道预览 → 六角色辅助(全部零 LLM)
    segs = [{"seg_id": "blk_%d" % (i + 1), "kind": "block", "label": "第 %d 块" % (i + 1),
             "text": s.get("text") or "", "source_refs": list(s.get("source_refs") or [])}
            for i, s in enumerate((OUT["versions"].get("current") or {}).get("segments") or [])]
    show("preview", C.post("/api/content/preview", json={"segments": segs}).json())
    show("assist", C.post("/api/content/assist",
                          json={"club_id": CLUB, "segments": segs}).json())
    show("assist_roles", C.get("/api/content/assist_roles").json())
    show("dashboard", C.get("/api/content/dashboard", params={"club_id": CLUB}).json())
    rec = C.get("/api/content/review_record", params={"club_id": CLUB}).json()
    show("review_record", rec)
    ex = C.get("/api/content/review_export", params={"club_id": CLUB})
    print("review_export:", ex.status_code, ex.headers.get("content-type"),
          len(ex.text), "字节")
    pk = C.get("/api/content/export_package", params={"club_id": CLUB})
    print("export_package:", pk.status_code, pk.headers.get("content-type"),
          len(pk.text), "字节")
    an = C.post("/api/content/analyze",
                json={"club_id": CLUB, "text": "这次比赛反响热烈，是最好的一届。"
                                               "想咨询的同学请联系张同学，电话13812345678。"}).json()
    show("analyze", an)
    ing = C.post("/api/content/ingest", json={
        "club_id": CLUB,
        "materials": [{"content": "补录: 本届比赛志愿者共50人到场。", "source": "organizer",
                       "subject": "补录素材", "type": "activity"}],
    }).json()
    show("ingest", ing)
    # 矛盾裁决需要先有矛盾缺口
    cl = OUT["checklist"]["check_list"]
    conf = [c for c in cl if c["weakness_type"] == "conflict" and c.get("candidates")]
    if conf:
        eid = conf[0]["candidates"][0]["eid"]
        show("resolve_conflict",
             C.post("/api/content/resolve_conflict",
                    json={"club_id": CLUB, "chosen_eid": eid,
                          "seg_id": conf[0].get("seg_id") or ""}).json())
    else:
        print("(本轮演示语料无 conflict 候选, 跳过 resolve_conflict)")
    show("rollback", C.post("/api/content/rollback",
                            json={"club_id": CLUB, "to_seq": 3,
                                  "reason": "probe"}).json())
    snap = os.path.join(_TMP, "shapes.json")
    with open(snap, "w", encoding="utf-8") as f:
        json.dump(OUT, f, ensure_ascii=False, indent=1)
    print("\n结构快照: %s" % snap)
    print("(test/_test_workbench_dom.mjs 会读它做 DOM 断言; 丢了就重跑本脚本即可)")


if __name__ == "__main__":
    main()
