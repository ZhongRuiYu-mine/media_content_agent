# coding: utf-8
"""_test_graphstore.py — FileGraphStore 离线验证(design/02 §7 断言)。"""
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from graphstore import FileGraphStore  # noqa: E402

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "_test_graphstore_tmp")


def rec(type_, subject, content, period=None, techs=None, metrics=None):
    return {"type": type_, "subject": subject, "content": content,
            "period": period, "techs": techs or [],
            "metrics": metrics or [], "claims": [], "source": "resume"}


def state_sig(state: dict) -> str:
    return json.dumps(state, ensure_ascii=False, sort_keys=True)


def main():
    sid = "student_t1"
    root = os.path.join(BASE, "store_a")
    st = FileGraphStore(root, sid, snapshot_every=20)
    st.open()

    # 1) 提交 3 个事件 + 1 个弱记忆(seq 1..4)
    st.commit("ADD_EVENT", {"record": rec("project", "智能推荐系统",
                                          "基于协同过滤和深度学习的混合推荐系统 处理10万级用户行为数据",
                                          period={"start": "2024-03", "end": "2024-08",
                                                  "precision": "month", "raw": "2024.03-2024.08"},
                                          techs=["pytorch", "redis", "docker"],
                                          metrics=[{"key": "accuracy", "value": 15, "unit": "%",
                                                    "kind": "delta", "raw": "准确率提升15%"}])}, session_id="s1")
    st.commit("ADD_EVENT", {"record": rec("competition", "数学建模竞赛", "全国大学生数学建模竞赛 国家一等奖",
                                          period={"start": "2023", "end": None,
                                                  "precision": "year", "raw": "2023"})}, session_id="s1")
    st.commit("ADD_EVENT", {"record": rec("skill", "Python", "Python 熟练使用")}, session_id="s1")
    assert st.head_seq == 3
    # 自动边: E1-techs ∩ E2? none; E1 与 E3 无交集 → entity 空; 验证纯文本规则
    edges = st.latest()["edges"]["entity"]
    assert len(edges) == 0, edges

    st.commit("ADD_WEAK", {"event_id": "evt_000001", "weakness_type": "isolated",
                           "priority": 0.6, "reason": "孤立待连接"}, session_id="s1")
    assert st.head_seq == 4
    assert len(st.latest()["weak"]) == 1
    sig_at_4 = state_sig(st.latest())
    st.snapshot(reason="manual")

    # 2) 再次提交一个与 E1 共享 tech 的事件 → entity 边出现
    st.commit("ADD_EVENT", {"record": rec("project", "推荐系统A", "推荐系统A 用了pytorch",
                                          techs=["pytorch"])}, session_id="s1")
    edges = st.latest()["edges"]["entity"]
    assert any(e.get("kind") == "shared_tech" for e in edges.values()), edges
    sig_at_5 = state_sig(st.latest())

    # 3) 重开实例(模拟重启) → 状态与内存一致(纯重放)
    st2 = FileGraphStore(root, sid, snapshot_every=20)
    st2.open()
    assert st2.head_seq == 5
    assert state_sig(st2.latest()) == sig_at_5, "重放后状态不一致"

    # 4) 回滚到 seq=4 → weak 1 条、事件 3 个; 再追加 seq=4 事件不冲突
    rb = st2.rollback(4, session_id="s2", reason="test")
    assert rb["rolled_back"] is True
    assert len(st2.latest()["events"]) == 3
    assert len(st2.latest()["weak"]) == 1
    assert state_sig(st2.latest()) == sig_at_4, "回滚到4与当时不一致"
    st2.commit("ADD_EVENT", {"record": rec("project", "二手交易平台",
                                           "校园二手交易平台 日活500+", techs=["springboot"])}, session_id="s2")
    assert st2.head_seq == 5
    st3 = FileGraphStore(root, sid, snapshot_every=20)
    st3.open()
    assert st3.head_seq == 5

    # 5) 崩溃半行容错: 手动往 log 追加未完成的半行 → 打开应忽略
    with open(os.path.join(root, sid, "log.jsonl"), "a", encoding="utf-8") as f:
        f.write('{"seq": 999, "op": "ADD_EVENT", "payl')
    st4 = FileGraphStore(root, sid, snapshot_every=20)
    st4.open()
    assert st4.head_seq == 5
    assert len(st4.latest()["events"]) == 4

    # 6) 撤销上一步 = rollback(head-1) 可反复
    h5 = st4.rollback(4)
    assert h5["rolled_back"] is True
    assert len(st4.latest()["events"]) == 3
    st4.rollback(0)  # 回到空态
    assert len(st4.latest()["events"]) == 0
    print("graphstore tests PASSED")


if __name__ == "__main__":
    try:
        main()
    finally:
        shutil.rmtree(BASE, ignore_errors=True)
