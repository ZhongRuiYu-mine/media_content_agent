/* test/_wb_dom_shim.mjs — 极简 DOM 垫片, 只为在 Node 里**真的执行** static/workbench.js。
 *
 * 为什么需要: 前端零构建、无依赖, 没有 jsdom 可用; 但"渲染函数能不能跑通"必须自测,
 * 否则只能靠肉眼看代码。这个垫片实现 workbench.js 用到的那些 API:
 *   document.getElementById / querySelector(All) / createElement / createTreeWalker
 *   element.innerHTML(可读可写, 写时用一个小解析器建子节点) / textContent / classList /
 *   dataset / appendChild / addEventListener / click / scrollIntoView
 *   Range + NodeFilter(溯源点击的同步高亮要在真实文本节点上切分)
 * 它不追求 DOM 完整性, 只保证 workbench.js 的行为可以在这里被断言。
 */

function camelToDash(s) {
  return s.replace(/[A-Z]/g, (m) => "-" + m.toLowerCase());
}

class ClassList {
  constructor(el) { this.el = el; this.set = new Set(); }
  add(...cs) { cs.forEach((c) => c && this.set.add(c)); }
  remove(...cs) { cs.forEach((c) => this.set.delete(c)); }
  contains(c) { return this.set.has(c); }
  toggle(c, force) {
    const on = force === undefined ? !this.set.has(c) : !!force;
    if (on) this.set.add(c); else this.set.delete(c);
    return on;
  }
  toString() { return [...this.set].join(" "); }
}

class TextNode {
  constructor(v) { this.nodeType = 3; this.nodeValue = String(v); this.parentNode = null; }
  get textContent() { return this.nodeValue; }
  get outerHTML() { return escapeText(this.nodeValue); }
  get className() { return ""; }
  get tagName() { return "#text"; }
  querySelectorAll() { return []; }
  querySelector() { return null; }
}

class CommentNode {
  constructor(v) { this.nodeType = 8; this.nodeValue = String(v); this.parentNode = null; }
  get textContent() { return ""; }
  get outerHTML() { return "<!--" + this.nodeValue + "-->"; }
  get className() { return ""; }
  get tagName() { return "#comment"; }
  querySelectorAll() { return []; }
  querySelector() { return null; }
}

function escapeText(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

class Dataset {
  constructor(el) { this.el = el; }
  _key(prop) { return "data-" + camelToDash(prop); }
  set(prop, val) { this.el.attrs[this._key(prop)] = String(val); }
  get(prop) { return this.el.attrs[this._key(prop)]; }
}

class Element {
  constructor(tag) {
    this.nodeType = 1;
    this.tagName = String(tag).toUpperCase();
    this.childNodes = [];
    this.parentNode = null;
    this.attrs = {};
    this.dataset = new Proxy(new Dataset(this), {
      get: (t, p) => (typeof p === "string" ? t.get(p) : t[p]),
      set: (t, p, v) => { t.set(p, v); return true; }
    });
    this.style = {};
    this.listeners = {};
    this.classList = new ClassList(this);
  }

  get className() { return this.classList.toString(); }
  set className(v) {
    this.classList.set = new Set(String(v || "").split(/\s+/).filter(Boolean));
  }

  setAttribute(k, v) {
    this.attrs[k] = String(v);
    if (k === "class") this.className = v;
    if (k.startsWith("data-")) this.dataset[k.slice(5)] = String(v);
  }

  getAttribute(k) { return this.attrs[k]; }

  /** className 直接改的时候(不走 setAttribute), 序列化也要跟上 */
  _syncClass() {
    const s = this.classList.toString();
    if (s) this.attrs["class"] = s; else delete this.attrs["class"];
  }

  appendChild(node) {
    if (!node) return node;
    if (node.parentNode) node.parentNode.removeChild(node);
    node.parentNode = this;
    this.childNodes.push(node);
    return node;
  }

  insertBefore(node, ref) {
    node.parentNode = this;
    const i = this.childNodes.indexOf(ref);
    if (i < 0) this.childNodes.push(node); else this.childNodes.splice(i, 0, node);
    return node;
  }

  removeChild(node) {
    const i = this.childNodes.indexOf(node);
    if (i >= 0) this.childNodes.splice(i, 1);
    node.parentNode = null;
    return node;
  }

  remove() { if (this.parentNode) this.parentNode.removeChild(this); }

  normalize() {}

  get children() { return this.childNodes.filter((n) => n.nodeType === 1); }

  /** 浏览器里 parentElement 与 parentNode 等价(只在父节点是元素时非 null) */
  get parentElement() {
    return this.parentNode && this.parentNode.nodeType === 1 ? this.parentNode : null;
  }

  get firstChild() { return this.childNodes[0] || null; }

  contains(n) {
    while (n) { if (n === this) return true; n = n.parentNode; }
    return false;
  }

  get outerHTML() {
    this._syncClass();
    const attrs = Object.keys(this.attrs)
      .map((k) => " " + k + '="' + escapeAttr(this.attrs[k]) + '"').join("");
    return "<" + this.tagName.toLowerCase() + attrs + ">" +
      this.childNodes.map((n) => n.outerHTML).join("") +
      "</" + this.tagName.toLowerCase() + ">";
  }

  get innerHTML() { return this.childNodes.map((n) => n.outerHTML).join(""); }

  set innerHTML(html) {
    this.childNodes = [];
    parseInto(this, String(html == null ? "" : html));
  }

  get textContent() { return this.childNodes.map((n) => n.textContent).join(""); }

  set textContent(v) {
    this.childNodes = [];
    if (v !== "" && v != null) this.appendChild(new TextNode(v));
  }

  addEventListener(type, fn) {
    (this.listeners[type] = this.listeners[type] || []).push(fn);
  }

  removeEventListener(type, fn) {
    const list = this.listeners[type] || [];
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  }

  /** 触发一次 click(垫片专用, 不是标准 API) */
  click(init) {
    const ev = Object.assign({
      target: this, stopPropagation() {}, preventDefault() {},
      clientX: 100, clientY: 100
    }, init || {});
    (this.listeners.click || []).forEach((fn) => fn(ev));
  }

  scrollIntoView() {}
  focus() { if (this.ownerDocument) this.ownerDocument.activeElement = this; }
  blur() {}

  querySelectorAll(sel) {
    const groups = String(sel).split(",").map((s) => s.trim()).filter(Boolean);
    const out = [];
    groups.forEach((g) => {
      const parts = g.split(/\s+/);
      const last = parts.pop();
      let scope = [this];
      parts.forEach((p) => {
        const next = [];
        scope.forEach((s) => {
          if (s !== this && matches(s, p)) next.push(s);
          walkAll(s, (el) => { if (matches(el, p)) next.push(el); });
        });
        scope = next;
      });
      scope.forEach((s) => {
        if (s !== this && matches(s, last) && !out.includes(s)) out.push(s);
        walkAll(s, (el) => {
          if (matches(el, last) && !out.includes(el)) out.push(el);
        });
      });
    });
    return out;
  }

  querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }

  /** 向上找最近的匹配祖先（拖拽落点判定用） */
  closest(sel) {
    let el = this;
    while (el) {
      if (el.nodeType === 1 && matches(el, sel)) return el;
      el = el.parentNode;
    }
    return null;
  }

  /**
   * 垫片专用"伪布局"：没有真实排版引擎，所以按文档顺序给一个稳定尺寸。
   * 只保证"有非零尺寸 + 前后顺序"，用于验证"落在这一句的左半还是右半"这类
   * **相对**判定；不假装能验证像素级排版（那要真浏览器）。
   */
  getBoundingClientRect() {
    if (!this._rect) {
      const root = this.ownerDocument ? this.ownerDocument.documentElement : this;
      const all = [];
      (function walk(el) {
        el.childNodes.forEach((c) => { if (c.nodeType === 1) { all.push(c); walk(c); } });
      })(root);
      let i = all.indexOf(this);
      if (i < 0) i = 0;
      this._rect = {
        left: (i % 4) * 250, top: Math.floor(i / 4) * 24, width: 230, height: 20,
        right: (i % 4) * 250 + 230, bottom: Math.floor(i / 4) * 24 + 20
      };
    }
    return this._rect;
  }

  /** 触发任意事件（垫片专用）：拖拽测试要发 pointerdown / pointermove / pointerup */
  fire(type, init) {
    const ev = Object.assign({
      target: this, type: type, stopPropagation() {}, preventDefault() {},
      clientX: 100, clientY: 100
    }, init || {});
    let el = this;
    while (el) {
      (el.listeners[type] || []).forEach((fn) => fn(ev));
      el = el.parentNode;
    }
    if (this.ownerDocument) {
      (this.ownerDocument.listeners[type] || []).forEach((fn) => fn(ev));
    }
    return ev;
  }

  /**
   * 给元素指派一块"几何区域"（垫片专用）。
   * 没有排版引擎，测试就用它把关键元素的矩形摆成互不重叠、且与被测判定一致的形状，
   * 这样 elementFromPoint / 左右半区判定才是确定的 —— 而不是靠猜文档顺序。
   */
  place(left, top, width, height) {
    this._left = left;
    this._top = top;
    this._w = width;
    this._h = height;
    this._rect = {
      left: left, top: top, width: width, height: height,
      right: left + width, bottom: top + height
    };
    this._placed = true;
    return this;
  }

  /** 该元素是否被显式摆放过（供 elementFromPoint 优先取"已摆放"的元素） */
  get placed() { return !!this._placed; }
}

function walkAll(el, fn) {
  el.childNodes.forEach((c) => {
    if (c.nodeType === 1) { fn(c); walkAll(c, fn); }
  });
}

/** 支持 `tag.class.class[attr="v"]` 复合选择器(workbench.js 全部选择器用法都覆盖)。 */
function matches(el, sel) {
  if (!sel) return false;
  sel = sel.trim();
  const re = /([a-zA-Z][\w-]*)|\.([\w-]+)|#([\w-]+)|\[([\w-]+)(?:=["']?([^\]"']*)["']?)?\]/g;
  let m;
  let seen = false;
  while ((m = re.exec(sel))) {
    seen = true;
    if (m[1] && el.tagName !== m[1].toUpperCase()) return false;
    if (m[2] && !el.classList.contains(m[2])) return false;
    if (m[3] && el.attrs.id !== m[3]) return false;
    if (m[4]) {
      const v = el.attrs[m[4]];
      if (v === undefined) return false;
      if (m[5] !== undefined && v !== m[5]) return false;
    }
  }
  return seen;
}

/* ---------- 极简 HTML 解析(只服务 innerHTML 写入) ---------- */
const VOID_TAGS = new Set(["br", "hr", "img", "input", "meta", "link"]);

function parseInto(root, html) {
  const tagRe = /<!--[\s\S]*?-->|<\/?([a-zA-Z][a-zA-Z0-9]*)((?:\s+[^>]*?)?)\/?>/g;
  let stack = [root];
  let last = 0;
  let m;
  while ((m = tagRe.exec(html))) {
    if (m.index > last) {
      const text = decode(html.slice(last, m.index));
      if (text) stack[stack.length - 1].appendChild(new TextNode(text));
    }
    last = tagRe.lastIndex;
    if (m[0].startsWith("<!--")) {
      stack[stack.length - 1].appendChild(new CommentNode(m[0].slice(4, -3)));
      continue;
    }
    const closing = m[0].startsWith("</");
    const tag = m[1].toLowerCase();
    if (closing) {
      const i = stack.findLastIndex((e) => e.tagName === tag.toUpperCase());
      if (i > 0) stack = stack.slice(0, i);
      continue;
    }
    const el = new Element(tag);
    el.ownerDocument = root.ownerDocument || null;
    const attrs = m[2] || "";
    const aRe = /([\w-]+)(?:="([^"]*)")?/g;
    let a;
    while ((a = aRe.exec(attrs))) {
      el.setAttribute(a[1], a[2] === undefined ? "" : decode(a[2]));
    }
    stack[stack.length - 1].appendChild(el);
    if (!VOID_TAGS.has(tag) && !m[0].endsWith("/>")) stack.push(el);
  }
  if (last < html.length) {
    const text = decode(html.slice(last));
    if (text) stack[stack.length - 1].appendChild(new TextNode(text));
  }
}

function decode(s) {
  return String(s).replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'");
}

function escapeAttr(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
    .replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/* ---------- document ---------- */
export function createDom(html) {
  const root = new Element("body");
  parseInto(root, html);
  const byId = new Map();
  const collect = (el) => {
    if (el.attrs && el.attrs.id) byId.set(el.attrs.id, el);
    el.childNodes.forEach((c) => { if (c.nodeType === 1) collect(c); });
  };
  collect(root);

  const document = {
    readyState: "complete",
    body: root,
    documentElement: root,
    listeners: {},
    getElementById(id) { return byId.get(id) || null; },
    querySelector(sel) {
      if (sel === "body") return root;
      if (sel === ".toast") return null;
      return root.querySelector(sel);
    },
    querySelectorAll(sel) {
      if (sel === "body") return [root];
      return root.querySelectorAll(sel);
    },
    createElement(tag) {
      // 动态建出来的节点也要知道自己的 document: 事件冒泡要靠 ownerDocument 找到
      // 挂在 document 上的监听器(拖拽就是这么绑的), 否则测试会悄悄测不到真实路径。
      const el = new Element(tag);
      el.ownerDocument = document;
      return el;
    },
    createElementNS(ns, tag) {
      const el = new Element(tag);
      el.namespaceURI = ns;
      el.ownerDocument = document;
      return el;
    },
    createTextNode(v) { return new TextNode(v); },
    createRange() { return new FakeRange(); },
    createTreeWalker(node) { return new FakeWalker(node); },
    addEventListener(type, fn) {
      (this.listeners[type] = this.listeners[type] || []).push(fn);
    },
    removeEventListener(type, fn) {
      const list = this.listeners[type] || [];
      const i = list.indexOf(fn);
      if (i >= 0) list.splice(i, 1);
    }
  };
  attachDoc(root, document);
  return { document, root, byId };
}

/** 把 ownerDocument 补到整棵树上（事件冒泡要靠它找到 document 上的监听器）。 */
function attachDoc(root, document) {
  root.ownerDocument = document;
  root.childNodes.forEach((c) => { if (c.nodeType === 1) attachDoc(c, document); });
}

class FakeWalker {
  constructor(root) { this.stack = [...(root.childNodes || [])].reverse(); }
  nextNode() {
    while (this.stack.length) {
      const n = this.stack.pop();
      if (n.nodeType === 3) return n;                 // 文本节点: 就是它
      const kids = [...(n.childNodes || [])].reverse();
      kids.forEach((k) => this.stack.push(k));
    }
    return null;
  }
}

/** 只实现 surroundContents: 把 [start,end) 里的文本切出来包一个 mark。 */
class FakeRange {
  setStart(node, offset) { this.startNode = node; this.startOffset = offset; }
  setEnd(node, offset) { this.endNode = node; this.endOffset = offset; }

  surroundContents(mark) {
    if (this.startNode !== this.endNode) {
      throw new Error("跨节点 Range 由垫片拒绝（真实浏览器支持）");
    }
    const node = this.startNode;
    const parent = node.parentNode;
    const text = node.nodeValue;
    const before = new TextNode(text.slice(0, this.startOffset));
    const mid = new TextNode(text.slice(this.startOffset, this.endOffset));
    const after = new TextNode(text.slice(this.endOffset));
    const i = parent.childNodes.indexOf(node);
    parent.removeChild(node);
    const parts = [before, mark, after].filter((p) => p.nodeType !== 3 || p.nodeValue);
    parts.forEach((p, k) => {
      p.parentNode = parent;
      parent.childNodes.splice(i + k, 0, p);
    });
    mark.appendChild(mid);
  }
}

export { Element, TextNode, matches, camelToDash };
