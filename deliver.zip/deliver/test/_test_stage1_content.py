# coding: utf-8
"""_test_stage1_content.py — 阶段 1(采编相)验证: design/11 §9 T1.1–T1.4 + 验收 A1。

覆盖:
  T1.1 material_ops: 权威度推断 / cites 边推导 / 实体抽取 / 支撑判定
  T1.2 fact_verifier: 断言抽取 + 支撑判定 + 五类缺口(全部零 LLM)
  T1.3 classifier: 内容域裁决矩阵(R7 场地比对) + 原裁决矩阵不受影响
  T1.4 素材库视图(徽章/类型/时间线) — 前端左栏的数据源
  验收 A1: 零 LLM 模式跑通"散料 → 素材图 + 五类缺口各有至少 1 例"

**零 LLM 断言**: 本测试在 main() 开头把 LLM 闸门设为 auto_deny, 并校验
LLM_CALL_POINTS 的默认点在 auto_deny 下一律不放行(证明确定性链路自己就能跑通)。
"""
import asyncio
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["LLM_GATE_MODE"] = "auto_deny"          # 开发/测试: 一律零 LLM
os.environ["EMBEDDING_OFF"] = "1"                  # 纯规则路径(不加载向量模型)

from graphstore import FileGraphStore  # noqa: E402
from graphstore.types import (  # noqa: E402
    CONFLICT, ISOLATED, NO_SOURCE, SENSITIVE, STALE, GAP_TYPES,
    authority_of, authority_band,
)
from content import demo_corpus as corpus  # noqa: E402
from content.material_ops import (  # noqa: E402
    authority_mean, derive_cites, extract_entities, find_support, infer_authority,
    known_terms, segment_claims, segment_source_refs,
)
from content.fact_verifier import (  # noqa: E402
    GAP_ORDER, activity_window, blocking_gaps, check_list, detect_conflicts,
    detect_sensitive, is_conflicting_claim, is_isolated, is_stale, top_weak_sorted,
    verify_draft,
)
from content.material_analyst import (  # noqa: E402
    analyze_material_text, build_material_record, ingest_materials, material_badge,
    materials_of,
)
from components import llm_gate  # noqa: E402

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "data", "_test_stage1_tmp")
FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def _materials(eids=None):
    """构造带 eid 的素材列表(与 graphstore 落盘形状一致)。"""
    out = []
    for i, m in enumerate(corpus.all_materials(), start=1):
        rec = build_material_record(m)
        rec["eid"] = f"evt_{i:06d}"
        rec["created_seq"] = i
        if eids is None or rec["eid"] in eids:
            out.append(rec)
    return out


# ---------- T1.1 ----------
def test_material_ops():
    print("[T1.1] material_ops: 权威度 / 实体 / cites")
    check("官方文档权威度 1.00", infer_authority("official_doc") == 1.00)
    check("转述权威度 0.30", infer_authority("hearsay") == 0.30)
    check("未知来源不猜高", infer_authority("wechat") == 0.30)
    check("verified 不改变权威度数值", infer_authority("member", True) == authority_of("member"))

    mats = _materials()
    check("权威度分档 5 档可用",
          authority_band(1.0) == "official" and authority_band(0.3) == "hearsay")
    check("权威度均值计算", 0.0 < authority_mean(mats) < 1.0, authority_mean(mats))

    known = known_terms(mats)
    check("素材库沉淀人名词典(姓+称呼)",
          any(len(p) >= 2 and p[0] in "王李张" for p in known["person"]),
          known["person"][:6])

    ents = extract_entities("指导老师王老师在第三报告厅为参赛队伍做赛前动员", known)
    kinds = {e["kind"] for e in ents}
    check("抽出职务", "role" in kinds, ents)
    check("抽出场地(带限定前缀)", any(e["kind"] == "venue" for e in ents), ents)
    check("抽出人名词典命中", any(e["kind"] == "person" for e in ents), ents)
    check("抽出机构", any(e["kind"] == "org" for e in
                          extract_entities("本届比赛由计算机学院学生科技社团主办", known)),
          extract_entities("本届比赛由计算机学院学生科技社团主办", known))
    check("机构抽取不吞动词",
          all(not e["text"].startswith(("举办", "由", "本届"))
              for e in extract_entities("本届比赛由计算机学院学生科技社团主办", known)))

    # 支撑判定: 200 人有支撑(群公告), 250 人无支撑
    c200 = [c for c in segment_claims({"text": "预计约200人参加"}, mats)
            if c["key"] == "attendees"][0]
    check("200 人有支撑", len(find_support(c200, mats)) >= 1, find_support(c200, mats))
    c250 = dict(c200, value=250.0)
    check("250 人无支撑", find_support(c250, mats) == [])

    # 实体断言: 时间/人名
    seg = {"seg_id": "seg_lead",
           "text": "11月20日, 本届编程马拉松比赛在第三报告厅举行, 主办方为计算机学院学生科技社团。",
           "source_refs": []}
    cites = derive_cites(seg, mats)
    check("cites 边有向键 seg>eid", all(e["key"] == f"seg_lead>{e['tgt']}" for e in cites),
          cites[:3])
    check("cites 边能指回素材", len(cites) >= 1, cites[:3])
    check("段落来源指针可用", isinstance(segment_source_refs(seg, mats), list))
    check("cites 边键格式与 graphstore 一致(_DIRECTED)",
          all("|" not in e["key"] for e in cites))


# ---------- T1.2 ----------
def test_fact_verifier():
    print("[T1.2] fact_verifier: 断言 / 支撑 / 五类缺口")
    mats = _materials()

    # 隐私模式
    s = detect_sensitive("想报名的同学请联系张同学，手机13812345678，或到3号楼412室咨询。")
    check("命中手机号", any(h["pattern"] == "phone" for h in s), s)
    check("脱敏后不出现完整号码", all("13812345678" not in h["sample"] for h in s), s)
    check("正常数字不误报", detect_sensitive("到场183人，报名12支队伍") == [])
    # 楼栋房间号(社团报名通知里最常见的住址形态, 曾经漏检)
    room = detect_sensitive("或到3号宿舍楼412室现场咨询")
    check("命中楼栋房间号", any(h["pattern"] == "room" for h in room), room)
    check("命中办公室房间号",
          any(h["pattern"] == "room" for h in detect_sensitive("办公室在行政楼302室")))
    check("正常场地名不误报为住址",
          detect_sensitive("本次活动在大学生活动中心举行") == []
          and detect_sensitive("第三报告厅、图书馆、操场") == [])

    # 素材库内部矛盾
    w = activity_window(mats)
    check("活动窗口取最新 period", w["current"].startswith("2025"), w)
    confs = detect_conflicts([m for m in mats], w)
    r3 = [c for c in confs if c.get("rule") == "R3"]
    check("检出 R3 数字矛盾(200 vs 183)", len(r3) >= 1, [c["reason"] for c in confs])
    if r3:
        vals = {str(c["value"]) for c in r3[0]["candidates"]}
        check("矛盾并列两个版本", "200.0" in vals and "183.0" in vals, vals)
        check("矛盾给出优先候选(高权威在前)", r3[0]["preferred_eid"] is not None, r3[0])
    check("队伍数两届不同不误判矛盾",
          any(c.get("metric_key") == "teams" and c.get("rule") == "R3" for c in confs),
          [(c.get("metric_key"), c.get("reason")) for c in confs])
    check("队伍数矛盾候选是当年两条",
          all(all(str(x.get("eid")) != "evt_000001"
                  for x in c.get("candidates") or [])
              for c in confs if c.get("metric_key") == "teams"),
          [c.get("candidates") for c in confs if c.get("metric_key") == "teams"])
    check("日期不被当成指标",
          not any(str(x.get("unit") or "").endswith("月")
                  for c in confs for x in c.get("candidates") or []),
          [(c.get("metric_key"), c.get("candidates")) for c in confs])
    # 断言级: 稿件的 200 是矛盾双方之一且已被权威度裁定; 300/500 谁都没说过(无据)
    w0 = activity_window(mats)
    check("205 人落在矛盾上但已被裁定(不算未决)",
          not is_conflicting_claim({"kind": "metric", "key": "attendees",
                                    "value": 205.0, "raw": "", "mention": "205人"},
                                   mats, w0))
    check("300 人不在任何说法里(是无据不是矛盾)",
          not is_conflicting_claim({"kind": "metric", "key": "attendees",
                                    "value": 300.0, "raw": "", "mention": "300人"},
                                   mats, w0))
    check("素材层面仍报出这条矛盾", len(r3) >= 1)

    # 过期与孤证(素材级)
    stale = [m for m in mats if is_stale(m, w)]
    check("检出过期素材(上届)", len(stale) >= 1, [m["eid"] for m in stale])
    check("当年素材不过期", not any(is_stale(m, w) for m in mats
                                    if str((m.get("period") or {}).get("raw", "")).startswith("11月20")
                                    and m["eid"] != "evt_000001"))
    dup = [m for m in mats if is_isolated(m, mats)]
    check("检出孤证素材", len(dup) >= 1, [m["eid"] for m in dup])

    # 整稿核验: 用统一演示稿件(content/demo_corpus.py 的 DEMO_DRAFT_SEGMENTS)
    draft = {"topic": corpus.CLUB_NAME + "编程马拉松比赛",
             "segments": [dict(s) for s in corpus.DEMO_DRAFT_SEGMENTS]}
    res = verify_draft(draft, mats)
    by = res["summary"]["by_type"]
    # 五类缺口在一份核验里全都要能被检出(段落级 + 素材级)
    check("五类缺口各有至少 1 例(整稿核验)",
          all(by.get(t, 0) >= 1 for t in GAP_TYPES), by)
    check("门禁: 涉隐私素材会阻断多平台适配", res["block"] is True, res["summary"])
    check("阻断项可单独取出", len(blocking_gaps(res["gaps"])) >= 1)
    check("裁定后的矛盾不再是阻断项",
          all(not g.get("blocking") for g in res["gaps"]
              if g["weakness_type"] == CONFLICT),
          [g.get("blocking") for g in res["gaps"] if g["weakness_type"] == CONFLICT])
    check("裁定结果并列两版供用户覆盖",
          all(len(g.get("candidates") or []) >= 2 and g.get("chosen")
              for g in res["gaps"] if g["weakness_type"] == CONFLICT),
          [g.get("resolution_note") for g in res["gaps"]
           if g["weakness_type"] == CONFLICT])
    check("排序: 阻断类(no_source)排在警告类(stale)之前",
          GAP_ORDER[res["gaps"][0]["weakness_type"]] < GAP_ORDER[STALE],
          res["gaps"][0]["weakness_type"])
    check("top_weak_sorted 取前 3", len(top_weak_sorted(res["gaps"], top=3)) == 3)
    check("top_weak_sorted 不给 top 时默认取 3",
          len(top_weak_sorted(res["gaps"])) == 3)
    check("核验报告不截断(全量缺口)", len(res["gaps"]) == res["summary"]["total"],
          (len(res["gaps"]), res["summary"]["total"]))

    cl = check_list(res["gaps"])
    check("待核实清单含断言原句", all(c["claim"] for c in cl), cl[:2])
    check("待核实清单含中文标签", all(c["label"] for c in cl))
    check("无据项指得回素材或标明无来源",
          all("source_eid" in c for c in cl))
    nosrc = [c for c in cl if c["weakness_type"] == NO_SOURCE]
    check("检出无据(反响热烈/好评如潮/300人)", len(nosrc) >= 1,
          [c["assertion"] for c in nosrc])
    check("无据项带阻断标记", all(c["blocking"] for c in nosrc))
    stale = [c for c in cl if c["weakness_type"] == STALE]
    check("引用往届的段落报过期而非无据", len(stale) >= 1,
          [(c["weakness_type"], (c["claim"] or "")[:24]) for c in cl])
    check("过期项指回往届素材",
          all(c["source_eid"] in ("evt_000001", "evt_000003") for c in stale),
          [c["source_eid"] for c in stale])
    sens = [c for c in cl if c["weakness_type"] == SENSITIVE]
    check("检出涉隐私", len(sens) >= 1, [(c["assertion"], c["reason"]) for c in sens])
    check("段落里的隐私阻断、素材里的只进清单",
          any(c["blocking"] for c in sens) and any(not c["blocking"] for c in sens),
          [(c["assertion"], c["blocking"]) for c in sens])

    # 有据的稿件: 不产生阻断(反向验证, 防止核验器"见谁都报")
    clean = {"topic": "x", "segments": [
        {"seg_id": "seg_1", "text": "11月20日在第三报告厅举办本届编程马拉松比赛。",
         "source_refs": []}]}
    r2 = verify_draft(clean, mats)
    check("干净段落不产生阻断", r2["block"] is False,
          [(g["weakness_type"], g["assertion"]) for g in r2["gaps"]])


# ---------- T1.3 ----------
async def test_classifier_content_rules():
    print("[T1.3] classifier: 内容域裁决矩阵(启用 R7)")
    evs = {
        "evt_1": {"eid": "evt_1", "subject": "本届编程马拉松比赛",
                  "content": "11月20日在第三报告厅举办本届编程马拉松比赛",
                  "techs": [], "metrics": [], "claims": [], "source": "official_doc"},
    }
    # 场地不同 → R7 冲突(内容域启用)
    v = await asyncio.wait_for(
        __import__("components.classifier", fromlist=["classify"]).classify(
            "11月20日在大学生活动中心举办本届编程马拉松比赛", evs,
            embedder=None, content_rules=True), timeout=10)
    check("R7 地点变更判冲突", v["kind"] == "conflict" and
          any(e["rule"] == "R7" for e in v["evidence"]), v)
    # 同场地 → 不判冲突(不为一条 R7 把正常素材全变成矛盾); 换措辞避免撞上 R1 判重
    v2 = await asyncio.wait_for(
        __import__("components.classifier", fromlist=["classify"]).classify(
            "比赛于11月20日在第三报告厅举办, 主办方为本社团", evs,
            embedder=None, content_rules=True), timeout=10)
    check("同场地不误判冲突", v2["kind"] != "conflict", v2)
    # 内容域信号词: 活动通知不再一律 low_confidence
    from components.classifier import _has_signal
    check("内容域信号词生效", _has_signal("本届比赛将于11月20日举行"))


# ---------- T1.4 / 验收 A1 ----------
async def test_intake_and_a1():
    print("[T1.4 + A1] 素材录入(素材图) → 五类缺口")
    store = FileGraphStore(BASE, "demo_club", snapshot_every=20)
    store.open()

    # 逐句裁决(前端左栏标色用)
    from graphstore.types import norm_text
    items = await analyze_material_text(corpus.SCATTERED_TEXT, {}, embedder=None)
    check("散料切成 6 句", len(items) == 6, len(items))
    check("每句带裁决与素材类型",
          all(i["verdict"]["kind"] and i["material_type"] for i in items), items[:1])

    got = ingest_materials(store, corpus.all_materials(), session_id="t1")
    check("素材全部入库", len(got) == len(corpus.all_materials()), len(got))
    check("权威度随素材落盘",
          {g["eid"]: g["authority"] for g in got}.get(got[0]["eid"]) == 1.00, got[0])
    check("素材类型六类之一", all(g["type"] for g in got))

    st = store.latest()
    mats = materials_of(st)
    check("素材图可读回", len(mats) == len(got), len(mats))
    badges = [material_badge(m) for m in mats]
    check("徽章给出权威度档", all(b["band"] for b in badges), badges[:2])

    # 时间点回滚:cites 边与素材一起回退(design/11 §9 验收 A2 的前半)
    seg = {"seg_id": "seg_lead", "text": "11月20日在第三报告厅举办本届编程马拉松比赛。",
           "source_refs": []}
    for e in derive_cites(seg, mats)[:1]:
        store.commit("ADD_EDGE", {"graph": "cites", "src": e["src"], "tgt": e["tgt"],
                                  "kind": e["kind"], "weight": e["weight"]},
                     session_id="t1")
    head_with_cites = store.head_seq
    check("cites 边落盘", len(store.latest()["edges"]["cites"]) >= 1)
    store.rollback(head_with_cites - 1, session_id="t1", reason="test")
    check("回滚后 cites 边消失", store.latest()["edges"]["cites"] == {})

    res = verify_draft({"topic": "本届编程马拉松比赛", "segments": [
        {"seg_id": "s1", "text": "11月20日在第三报告厅举办本届编程马拉松比赛, 由计算机学院学生科技社团主办。"},
        {"seg_id": "s2", "text": "签到表显示本届比赛实际到场183人。"},
        {"seg_id": "s3", "text": "本次比赛反响热烈, 好评如潮, 到场人数超过300人。"},
        {"seg_id": "s4", "text": "请联系张同学，电话13812345678。"},
        {"seg_id": "s5", "text": "上届比赛于2024年11月16日在大学生活动中心举行, 参赛队伍24支。"},
    ]}, mats)
    by = res["summary"]["by_type"]
    print("     缺口分布: " + ", ".join(f"{k}={v}" for k, v in by.items()))
    check("A1: 五类缺口各有至少 1 例", all(by.get(t, 0) >= 1 for t in GAP_TYPES), by)
    check("A1: 阻断类排在最前(先处理不许发的, 再处理警告)",
          GAP_ORDER[res["gaps"][0]["weakness_type"]] <= 1, res["gaps"][0]["weakness_type"])
    check("A1: 矛盾并列两个版本供用户裁决",
          all(len(g.get("candidates") or []) >= 2
              for g in res["gaps"] if g["weakness_type"] == CONFLICT),
          [g.get("candidates") for g in res["gaps"] if g["weakness_type"] == CONFLICT])
    check("A1: 门禁拦住在场稿件(涉隐私/无据阻断)",
          res["block"] is True, res["summary"])
    check("A1: 零 LLM(闸门 auto_deny 下默认点也不放行)",
          llm_gate.gate_mode() == "auto_deny"
          and not llm_gate.allowed("P2") and not llm_gate.allowed("P8"))


async def main():
    try:
        test_material_ops()
        test_fact_verifier()
        await test_classifier_content_rules()
        await test_intake_and_a1()
    finally:
        shutil.rmtree(BASE, ignore_errors=True)
    if FAILS:
        print("\n阶段1 内容域测试 FAILED: %d 项" % len(FAILS))
        raise SystemExit(1)
    print("\n阶段1 内容域测试 PASSED")


if __name__ == "__main__":
    asyncio.run(main())
