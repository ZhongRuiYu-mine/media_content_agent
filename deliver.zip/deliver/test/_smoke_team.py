# coding: utf-8
"""_smoke_team.py — R0.3 最小 TeamAgentSpec 冒烟（仅 leader，打印一次对话）。

目的：验证 openjiuwen agent_teams（swarm）在本机可 build + run + 输出，并且
     每一处 LLM 调用都能被项目的 llm_gate 审计到（哪里/何时/调用情况）。

隔离原则（不修改、不写任何项目已有代码/文件）：
  1. 只 import config（只读 .env）与 components.llm_gate（只读登记点 + 审计写入重定向）;
  2. 用 configure_openjiuwen_home() 把 openjiuwen 的 home 指到本脚本隔离目录，
     团队 DB / 工作区 / session 全部落隔离目录（不碰 ~/.openjiuwen，也不碰项目 data/）;
  3. 用 LLM_GATE_LOG 环境变量把审计写到隔离文件，避免污染 data/logs/llm_gate.jsonl;
  4. 全程只新建隔离目录，结束后自清理，项目文件只读。

运行：D:\\jiuwen\\Scripts\\python _smoke_team.py
"""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import uuid

# ---------------------------------------------------------------------------
# 0. 隔离前置：把所有写盘目标重定向到项目根下的隔离目录（workspace-write 可写）
# ---------------------------------------------------------------------------
_PROJ_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PROJ_DIR)  # 项目根
_SMOKE_DIR = os.path.join(_PROJ_DIR, "smoke_team_" + uuid.uuid4().hex[:8])
os.makedirs(_SMOKE_DIR, exist_ok=True)
os.environ["LLM_GATE_LOG"] = os.path.join(_SMOKE_DIR, "llm_gate.jsonl")
# 防误触：即便某些组件去读 STORAGE_BASE_DIR，也指向隔离目录（本脚本不建图）
os.environ["STORAGE_BASE_DIR"] = os.path.join(_SMOKE_DIR, "graphs")

# 统一 stdout/stderr 为 UTF-8，避免 Windows 控制台把中文打印成乱码
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass

from openjiuwen.agent_teams.paths import configure_openjiuwen_home  # noqa: E402

configure_openjiuwen_home(os.path.join(_SMOKE_DIR, "openjiuwen"))

# ---------------------------------------------------------------------------
# 1. 复用项目已有代码：config（只读 .env） + llm_gate（审计登记）
# ---------------------------------------------------------------------------
from config import DEFAULT_CONFIG  # noqa: E402
from components import llm_gate  # noqa: E402

# 登记本轮复盘/HITS 的 LLM 调用点（运行时登记到内存，不修改 llm_gate.py 文件）
llm_gate.LLM_CALL_POINTS["P11"] = {
    "label": "复盘协作(HITS/团队)",
    "default_allowed": True,
    "cost_label": "1",
}

# ---------------------------------------------------------------------------
# 2. 挂 LLM 审计钩子。openjiuwen 的 ModelClient 在每次 LLM 调用（invoke/stream）
#    都触发一次 LLM_OUTPUT（成功，含 model/provider/usage/response）或
#    LLM_CALL_ERROR（失败，含 error）。据此写"一次调用一条审计"进 llm_gate。
# ---------------------------------------------------------------------------
from openjiuwen.core.runner.callback import get_callback_framework  # noqa: E402
from openjiuwen.core.runner.callback.events import LLMCallEvents  # noqa: E402

_fw = get_callback_framework()


def _usage_str(u) -> str:
    if not u:
        return "?"
    if isinstance(u, dict):
        keys = [k for k in ("total_tokens", "prompt_tokens", "completion_tokens") if k in u]
        if keys:
            return ",".join(f"{k}={u[k]}" for k in keys)
    return str(u)[:80]


@_fw.on(LLMCallEvents.LLM_INPUT)
async def _gate_input(**kwargs):
    print(f"[gate·输入] 调用前 model={kwargs.get('model_name')} "
          f"provider={kwargs.get('model_provider')} "
          f"messages={len(kwargs.get('messages') or [])} "
          f"stream={kwargs.get('is_stream')}", flush=True)


@_fw.on(LLMCallEvents.LLM_OUTPUT)
async def _gate_output(**kwargs):
    model = kwargs.get("model_name") or "?"
    provider = kwargs.get("model_provider") or "?"
    resp = kwargs.get("response") or ""
    usage = _usage_str(kwargs.get("usage"))
    llm_gate.audit("P11", student_id="smoke", session_id="smoke_001",
                   decision="auto", ok=True,
                   note=f"model={model} provider={provider} usage[{usage}] chars={len(str(resp))}")
    print(f"[gate·输出] 调用后 model={model} provider={provider} "
          f"usage[{usage}] chars={len(str(resp))} ok=True", flush=True)


@_fw.on(LLMCallEvents.LLM_CALL_ERROR)
async def _gate_error(**kwargs):
    model = kwargs.get("model_name") or "?"
    provider = kwargs.get("model_provider") or "?"
    err = kwargs.get("error")
    llm_gate.audit("P11", student_id="smoke", session_id="smoke_001",
                   decision="auto", ok=False,
                   note=f"model={model} provider={provider} err={type(err).__name__}:{str(err)[:120]}")
    print(f"[gate·错误] model={model} provider={provider} "
          f"err={type(err).__name__}:{str(err)[:120]}", flush=True)


# ---------------------------------------------------------------------------
# 3. 构建最小 TeamAgentSpec（仅 leader），复用项目 LLM 配置
# ---------------------------------------------------------------------------
from openjiuwen.agent_teams import (  # noqa: E402
    DeepAgentSpec,
    LeaderSpec,
    TeamAgentSpec,
)
from openjiuwen.agent_teams.schema.deep_agent_spec import TeamModelConfig  # noqa: E402


def build_smoke_spec():
    cfg = DEFAULT_CONFIG
    model = TeamModelConfig(
        model_client_config=cfg.llm.to_client_config(),
        model_request_config=cfg.llm.to_request_config(),
    )
    return TeamAgentSpec(
        team_name="smoke_review",
        language="cn",
        spawn_mode="inprocess",      # 本机单进程（与 Web 服务一致）
        lifecycle="temporary",       # 冒烟：跑完即停，不残留 pool
        leader=LeaderSpec(
            member_name="review_host",
            display_name="复盘主持",
            desc="采编复盘主持人：读取素材库与稿件快照并主持复盘。",
            prompt="你是采编复盘主持人。用简洁中文直接回应用户，不要调用工具、不要建团队。",
        ),
        agents={
            "leader": DeepAgentSpec(
                model=model,
                max_iterations=4,       # 压低循环上限，避免冒烟跑飞
            ),
        },
    )


def _chunk_type(chunk) -> str:
    t = getattr(chunk, "type", None)
    if t is None and isinstance(chunk, dict):
        t = chunk.get("type") or chunk.get("event_type")
    return str(t or "")


def _chunk_payload(chunk) -> dict:
    p = getattr(chunk, "payload", None)
    if p is None and isinstance(chunk, dict):
        p = chunk.get("payload") or {}
    return p if isinstance(p, dict) else {}


# ---------------------------------------------------------------------------
# 4. 跑一次对话：收齐 leader 回答后在 team.idle 处主动结束，再打印审计汇总
# ---------------------------------------------------------------------------
async def main() -> int:
    from openjiuwen.core.runner import Runner

    cfg = DEFAULT_CONFIG
    print("=" * 70, flush=True)
    print(f"隔离目录: {_SMOKE_DIR}", flush=True)
    print(f"LLM: model={cfg.llm.model_name} provider={cfg.llm.provider} "
          f"api_key={'已配置' if cfg.llm.api_key else '缺失'}", flush=True)
    if not cfg.llm.api_key:
        print("!! .env 未配置 API_KEY，无法真实调用 LLM，冒烟中止。", flush=True)
        return 2
    print("=" * 70, flush=True)

    spec = build_smoke_spec()
    query = "你好，请用一句话说明你作为采编复盘主持人的职责。"
    print(f"[query] {query}\n", flush=True)

    try:
        await Runner.start()
    except Exception as e:  # noqa: BLE001 - start 可能已幂等
        print(f"[warn] Runner.start 忽略: {e}", flush=True)

    answer_text = ""
    saw_idle = False
    reasoning_chars = 0
    output_chars = 0
    try:
        async def _consume_inline():
            ans = ""
            idle = False
            rc = 0
            oc = 0
            async for chunk in Runner.run_agent_team_streaming(
                spec, {"query": query}, session="smoke_001"
            ):
                t = _chunk_type(chunk)
                p = _chunk_payload(chunk)
                if t == "message" and p.get("event_type") == "team.runtime_ready":
                    print(f"[team] runtime_ready team={p.get('team_name')} "
                          f"session={p.get('session_id')} kind={p.get('activation_kind')}", flush=True)
                elif t == "answer":
                    ans = p.get("output") or ""
                elif t == "llm_usage":
                    print(f"[usage] {p.get('usage_metadata', {})}", flush=True)
                elif t == "llm_reasoning":
                    rc += len(p.get("content") or "")
                elif t == "llm_output":
                    oc += len(p.get("content") or "")
                elif t == "message" and p.get("event_type") == "team.idle":
                    idle = True
                    print(f"[team] idle members={p.get('members')}", flush=True)
                    break
            return ans, idle, rc, oc

        answer_text, saw_idle, reasoning_chars, output_chars = await asyncio.wait_for(
            _consume_inline(), timeout=150
        )
    except asyncio.TimeoutError:
        print("\n[结果] 超时(150s)，未收到 team.idle。", flush=True)
        return 3
    finally:
        try:
            await Runner.stop()
        except Exception as e:  # noqa: BLE001
            print(f"[warn] Runner.stop 忽略: {e}", flush=True)

    print("-" * 70, flush=True)
    print(f"[leader 回答] {answer_text or '(空)'}", flush=True)
    print(f"[统计] reasoning_chars={reasoning_chars} output_chars={output_chars} "
          f"saw_idle={saw_idle}", flush=True)
    print("-" * 70, flush=True)

    counters = llm_gate.counters()
    print("[LLM 审计汇总] 总 default=%d authorized=%d unregistered=%d" % (
        counters.get("default", 0),
        counters.get("authorized", 0),
        counters.get("unregistered", 0),
    ), flush=True)
    for pid, p in (counters.get("by_point") or {}).items():
        print(f"  调用点 {pid}: default={p.get('default', 0)} authorized={p.get('authorized', 0)} "
              f"ok={p.get('ok', 0)} error={p.get('error', 0)}", flush=True)
    # openjiuwen 常驻团队的后台线程使 asyncio.run 无法正常返回, 流程完成后直接强制退出
    shutil.rmtree(_SMOKE_DIR, ignore_errors=True)
    os._exit(0)


if __name__ == "__main__":
    code = 1
    try:
        code = asyncio.run(main())
    except KeyboardInterrupt:
        code = 130
    except Exception:  # noqa: BLE001 - 顶层兜底，打印堆栈便于排查
        import traceback

        traceback.print_exc()
        code = 1
    finally:
        shutil.rmtree(_SMOKE_DIR, ignore_errors=True)
    print(f"\n[退出码] {code}", flush=True)
    sys.exit(code)
