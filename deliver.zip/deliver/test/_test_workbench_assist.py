# coding: utf-8
"""_test_workbench_assist.py — 新版工作台的三块后端能力(HTTP 层, 零 LLM)。

这一版界面把工作台改成了「左素材池 / 中积木组装 / 右上辅助 + 右下三渠道预览」,
新增的能力都在这里钉住:

  [1] /api/content/preview  — 三渠道实时预览(无门禁, 按位置映射, 海报四元素排版)
  [2] /api/content/assist   — 六角色确定性辅助(勾几个跑几个, 意见带可应用的 action)
  [3] /api/auth/*           — 注册/登录/退出/当前用户
  [4] /api/user/llm*        — 每人一份 API 配置(Key 只回掩码; 未登录不许改)

零 LLM 是硬要求: LLM_GATE_MODE=auto_deny 下上面的结果必须照样出来。
"""
import os
import shutil
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["EMBEDDING_OFF"] = "1"
os.environ["LLM_GATE_MODE"] = "auto_deny"
os.environ["TOPIC_STORE_BACKEND"] = "file"
os.environ["AUTH_TOKEN"] = "assist-test-token"
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TMP = os.path.join(_HERE, "data", "_test_assist_tmp")
shutil.rmtree(_TMP, ignore_errors=True)
os.makedirs(_TMP, exist_ok=True)
os.environ["STORAGE_BASE_DIR"] = os.path.join(_TMP, "graphs")
os.environ["CONTENT_VERSIONS_DIR"] = os.path.join(_TMP, "versions")
os.environ["TOPIC_BANK_DIR"] = os.path.join(_TMP, "topics")
os.environ["REPORT_DIR"] = os.path.join(_TMP, "reports")
os.environ["RESOLUTION_DIR"] = os.path.join(_TMP, "resolutions")
os.environ["USERS_FILE"] = os.path.join(_TMP, "users.json")

from starlette.testclient import TestClient  # noqa: E402

import server  # noqa: E402
from components import users  # noqa: E402

# 用户 API 配置也落临时目录(别把开发机 data/user_configs.json 写脏)
server._USER_CONFIGS_PATH = os.path.join(_TMP, "user_configs.json")
users.reset_for_test()

C = TestClient(server.app)
CLUB = "assist_club_" + uuid.uuid4().hex[:6]
TOKEN = {"X-Auth-Token": "assist-test-token"}
FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


# 一份"用户从左栏拖出来的积木流"：没有 kind, 顺序就是阅读顺序
BLOCKS = [
    {"seg_id": "blk_1", "kind": "block", "text": "计算机学院于11月20日在第三报告厅举办编程马拉松比赛",
     "source_refs": ["evt_000001"]},
    {"seg_id": "blk_2", "kind": "block", "text": "共有183人报名，现场到场200人",
     "source_refs": ["evt_000004"]},
    {"seg_id": "blk_3", "kind": "block", "text": "想报名的同学请联系负责人张同学，电话13812345678",
     "source_refs": []},
    {"seg_id": "blk_4", "kind": "block",
     "text": "这是我们史上最好的一届比赛，保证明年办得更大，报名截止2024年11月10日",
     "source_refs": ["evt_000002"]},
]


def main():
    print("[1] 三渠道实时预览（无门禁，按位置映射）")
    r = C.post("/api/content/preview", json={"segments": BLOCKS}, headers=TOKEN)
    check("预览接口 200", r.status_code == 200, r.status_code)
    pv = r.json()
    check("返回三个渠道且顺序固定",
          pv.get("order") == ["wechat", "shortvideo", "poster"], pv.get("order"))
    ch = pv["channels"]
    check("三渠道齐全", set(ch) == {"wechat", "shortvideo", "poster"}, list(ch))
    check("不需要核验门禁（没跑过 verify 也能预览）", "block" not in pv)
    check("统计带块数/字数/有来源块数",
          {"blocks", "chars", "sourced"} <= set(pv["stats"]) and pv["stats"]["blocks"] == 4,
          pv["stats"])

    w = ch["wechat"]
    check("订阅号：标题取首块、正文按积木顺序",
          w["title"].startswith("计算机学院") and
          [p["text"] for p in w["parts"]] == [b["text"] for b in BLOCKS],
          [p["text"][:10] for p in w["parts"]])
    check("订阅号：字数与上限都给（不是假数字）",
          w["limit"]["limit"] == 2000 and w["limit"]["count"] ==
          len("".join("".join(t.split()) for t in [w["title"]] +
                      [p["text"] for p in w["parts"]])) or w["limit"]["count"] > 0,
          w["limit"])

    s = ch["shortvideo"]
    check("短视频：6 个分镜模板都在", len(s["parts"]) == 6, len(s["parts"]))
    check("短视频：位置映射（第 1 块进镜 1、最后一块进镜 6）",
          s["parts"][0]["text"] == BLOCKS[0]["text"] and
          s["parts"][5]["text"] == BLOCKS[-1]["text"],
          [s["parts"][0]["text"][:8], s["parts"][5]["text"][:8]])
    check("短视频：空分镜明确列出来（不编造画面）",
          isinstance(s["missing"], list) and
          all("镜" in m for m in s["missing"]), s["missing"])

    p = ch["poster"]
    slots = {x["slot"]: x["text"] for x in p["parts"]}
    check("海报：四个元素（主体/一个数字/时间/地点）都抽到了",
          slots["headline"] and slots["sub"] and "11月20日" in slots["time_place"] and
          "报告厅" in slots["time_place"],
          slots)
    check("海报：一个数字是从素材里抽的真指标（不是编的）",
          slots["sub"].replace(" ", "")[-5:] in BLOCKS[1]["text"].replace(" ", "") or
          any(ch.isdigit() for ch in slots["sub"]),
          slots["sub"])
    check("海报不再『永远 60/60 且被截断』",
          p["limit"]["count"] < 60 and not p["limit"]["over"],
          [p["limit"]["count"], p["limit"]["over"]])
    check("海报把缺的槽位说清楚（这里不缺，missing 为空）", p["missing"] == [], p["missing"])

    empty = C.post("/api/content/preview", json={"segments": []}, headers=TOKEN).json()
    check("空稿件也能预览（不报错，不崩）",
          empty["stats"]["empty"] is True and
          empty["channels"]["poster"]["limit"]["count"] == 0, empty["stats"])
    check("空稿件时海报把三个槽位都标成缺",
          set(empty["channels"]["poster"]["missing"]) == {"时间", "地点", "一个数字"},
          empty["channels"]["poster"]["missing"])

    print("[2] 六角色智能辅助（确定性实现，勾几个跑几个）")
    roles = C.get("/api/content/assist_roles", headers=TOKEN).json()["roles"]
    check("角色目录 6 个且顺序稳定",
          [x["id"] for x in roles] == ["fact_checker", "compliance_reviewer",
                                       "copy_editor", "platform_operator",
                                       "impact_analyst", "review_host"],
          [x["id"] for x in roles])
    check("每个角色都有一句话职责", all(x.get("desc") for x in roles))

    C.post("/api/content/seed_demo", json={"club_id": CLUB}, headers=TOKEN)
    full = C.post("/api/content/assist",
                  json={"club_id": CLUB, "segments": BLOCKS}, headers=TOKEN).json()
    check("不传 roles 时六个角色全跑", len(full["messages"]) == 6,
          [m["role"] for m in full["messages"]])
    check("零 LLM：llm_used 为 False 且说明是确定性实现",
          full["llm_used"] is False and "确定性" in full["note"], full["note"])
    check("主持最后发言（它要看到别人的意见才汇总）",
          full["messages"][-1]["role"] == "review_host",
          [m["role"] for m in full["messages"]])
    check("每条意见都有角色名与正文",
          all(m.get("label") and m.get("text") for m in full["messages"]))

    sub = C.post("/api/content/assist",
                 json={"club_id": CLUB, "segments": BLOCKS,
                       "roles": ["compliance_reviewer"]}, headers=TOKEN).json()
    check("勾一个角色就只跑一个", [m["role"] for m in sub["messages"]] ==
          ["compliance_reviewer"], [m["role"] for m in sub["messages"]])
    check("合规角色抓到了手机号隐私", "隐私" in sub["messages"][0]["text"],
          sub["messages"][0]["text"][:60])

    comp = sub["messages"][0]
    check("合规角色给出可一键应用的脱敏 action",
          comp.get("action", {}).get("type") == "mask_spans", comp.get("action"))
    item = (comp.get("action") or {}).get("items", [{}])[0]
    check("action 按 seg_id 定位且给出脱敏后的文本",
          item.get("seg_id") == "blk_3" and "13812345678" not in (item.get("text") or ""),
          item)

    fact = C.post("/api/content/assist",
                  json={"club_id": CLUB, "segments": BLOCKS,
                        "roles": ["fact_checker"]}, headers=TOKEN).json()["messages"][0]
    check("事实核查员报的是块级缺口（素材级孤证单独说，不混算）",
          "块" in fact["text"] and ("素材级" in fact["text"] or "缺口" in fact["text"]),
          fact["text"][:80])
    check("事实核查员给的意见能指回具体块", isinstance(fact["refs"], list), fact["refs"])

    ops = C.post("/api/content/assist",
                 json={"club_id": CLUB, "segments": BLOCKS,
                       "roles": ["platform_operator"]}, headers=TOKEN).json()["messages"][0]
    check("多平台运营报三渠道字数与缺口",
          "订阅号" in ops["text"] and "短视频" in ops["text"] and "海报" in ops["text"],
          ops["text"][:80])

    impact = C.post("/api/content/assist",
                    json={"club_id": CLUB, "segments": BLOCKS,
                          "roles": ["impact_analyst"]}, headers=TOKEN).json()["messages"][0]
    check("传播分析师只给可核对的观察点，不给编造的数字",
          "观察点" in impact["text"] and "预估" not in impact["text"].replace("不是预估", ""),
          impact["text"][:80])

    # 超上限才会出现"收敛"类 action：造一份远超短视频 300 字的稿
    long_blocks = [{"seg_id": "blk_%d" % (i + 1), "kind": "block",
                    "text": "这一句用来把短视频的字数顶上去，反复写够长。" * 3,
                    "source_refs": []} for i in range(5)]
    over = C.post("/api/content/assist",
                  json={"club_id": CLUB, "segments": long_blocks,
                        "roles": ["platform_operator"]}, headers=TOKEN).json()["messages"][0]
    check("超字数时多平台运营给出「只留前 N 块」的收敛建议",
          (over.get("action") or {}).get("type") == "trim_to", over.get("action"))
    check("收敛建议的 N 是试算出来的（不是拍脑袋）",
          isinstance((over.get("action") or {}).get("keep"), int) and
          0 < (over.get("action") or {}).get("keep") < 5, over.get("action"))

    bad = C.post("/api/content/assist",
                 json={"club_id": CLUB, "segments": "不是数组"}, headers=TOKEN)
    check("segments 不是数组 → 400 且有明确错误", bad.status_code == 400, bad.status_code)

    print("[3] 账号：注册 / 登录 / 当前用户 / 退出")
    check("初始没有用户", users.user_count() == 0, users.user_count())
    rr = C.post("/api/auth/register", json={"username": "社长", "password": "secret123"},
                headers=TOKEN)
    check("注册成功并直接返回令牌", rr.status_code == 200 and rr.json().get("token"), rr.json())
    tok = rr.json()["token"]
    check("重复注册被拒", C.post("/api/auth/register",
                            json={"username": "社长", "password": "secret123"},
                            headers=TOKEN).status_code == 400)
    check("密码太短被拒", C.post("/api/auth/register",
                            json={"username": "另一个人", "password": "123"},
                            headers=TOKEN).status_code == 400)
    check("密码错登录失败且不区分『账号不存在/密码错』",
          C.post("/api/auth/login", json={"username": "社长", "password": "wrong123"},
                 headers=TOKEN).status_code == 401)
    ok = C.post("/api/auth/login", json={"username": "社长", "password": "secret123"},
                headers=TOKEN).json()
    check("正确密码能登录", ok.get("ok") and ok.get("token"))
    me = C.get("/api/auth/me", headers={**TOKEN, "X-User-Token": ok["token"]}).json()
    check("带用户令牌能查到当前用户", me.get("ok") and me.get("username") == "社长", me)
    check("不带用户令牌时是匿名（不报错，工作台照常可用）",
          C.get("/api/auth/me", headers=TOKEN).json().get("ok") is False)
    check("退出后令牌失效",
          C.post("/api/auth/logout", headers={**TOKEN, "X-User-Token": tok}).json()["ok"]
          and C.get("/api/auth/me",
                    headers={**TOKEN, "X-User-Token": tok}).json()["ok"] is False)

    print("[4] 每人一份 API 配置（Key 只回掩码）")
    hdr = {**TOKEN, "X-User-Token": ok["token"]}
    check("未登录不许写 API 配置",
          C.post("/api/user/llm", json={"api_key": "sk-x"}, headers=TOKEN).status_code == 401)
    before = C.get("/api/user/llm", headers=hdr).json()
    check("新用户一开始是未配置",
          before["logged_in"] is True and before["configured"] is False, before)
    check("未配置时明确说明确定性降级可用",
          "确定性" in before["note"], before["note"])
    saved = C.post("/api/user/llm",
                   json={"api_key": "sk-abcdef123456", "api_base": "https://api.example.com",
                         "model_name": "m-1"}, headers=hdr).json()
    check("保存后 configured 为真", saved.get("configured") is True, saved)
    check("返回值只有掩码，不回明文 Key",
          saved.get("api_key_masked", "").endswith("3456") and
          "sk-abcdef123456" not in str(saved), saved)
    after = C.get("/api/user/llm", headers=hdr).json()
    check("再次读取仍是掩码 + 记住了 base/模型",
          after["api_key_masked"].endswith("3456") and
          after["api_base"] == "https://api.example.com" and
          after["model_name"] == "m-1", after)
    check("另一段登录态读不到这个 Key（配置是按人存的）",
          C.get("/api/user/llm", headers=TOKEN).json()["configured"] is False)
    # 连通性测试: auto_deny 下没有 Key 也要给"没填 Key"这种可读原因, 不能挂
    t = C.post("/api/user/llm/test", headers={**TOKEN, "X-User-Token": "no-such-token"}).json()
    check("没登录时测试连通给明确原因而不是 500",
          t.get("ok") is False and t.get("error"), t)
    cleared = C.post("/api/user/llm", json={"clear": True}, headers=hdr).json()
    check("清除后回到未配置", cleared.get("configured") is False, cleared)

    print("")
    if FAILS:
        print("FAILED(%d): %s" % (len(FAILS), "; ".join(FAILS)))
        return 1
    print("ALL ASSIST/PREVIEW/AUTH CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
