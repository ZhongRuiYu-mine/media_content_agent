# coding: utf-8
"""_test_stage3_agents.py — 阶段 3(智能体相)验证: design/11 §9 T3.1–T3.4 + 验收 A3。

覆盖:
  T3.1 6 角色阵容(采编主持/事实核查员/文案编辑/多平台运营/合规风险审查/传播效果分析师)
       —— `/api/review/experts` 返回 6 角色
  T3.2 `content_tools` 工具换名换语义 —— 团队成员能读到**当时快照**素材与稿件
  T3.3 总编模式(一句话并行产出多平台)—— 命令注册、payload 自动装填、产出护栏(断言级 diff)
  T3.4 SSE 复盘面板 —— 事件名与流式输出契约、会话可重建(COLD_RECOVER)
  验收 A3: 起一场采编复盘, 6 角色名册齐全、状态可查

**离线**: 不开真实团队会话(那需要 LLM/网络), 只验证确定性部分:
名册、工具、快照绑定、payload 装填、事件与流契约。真实 LLM 会话由
`test/_smoke_team.py`(需要 API Key)覆盖。
"""
import asyncio
import json
import os
import shutil
import sys
import uuid

_PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PROJ)
_TMP = os.path.join(_PROJ, "test_s3_" + uuid.uuid4().hex[:8])
os.makedirs(_TMP, exist_ok=True)

os.environ["STORAGE_BASE_DIR"] = os.path.join(_TMP, "graphs")
os.environ["REPORT_DIR"] = os.path.join(_TMP, "reports")
os.environ["CONTENT_VERSIONS_DIR"] = os.path.join(_TMP, "versions")
os.environ["TOPIC_BANK_DIR"] = os.path.join(_TMP, "topics")
os.environ["REVIEWS_HOME"] = os.path.join(_TMP, "reviews")
os.environ["LLM_GATE_LOG"] = os.path.join(_TMP, "llm_gate.jsonl")
os.environ["EMBEDDING_OFF"] = "1"
os.environ["LLM_GATE_MODE"] = "auto_deny"
os.environ["TOPIC_STORE_BACKEND"] = "file"
os.environ.setdefault("PYTHONIOENCODING", "utf-8")
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass

from content import demo_corpus as corpus                       # noqa: E402
from content.content_runtime import ContentRuntime              # noqa: E402
from components import review_bridge, review_graph, review_runtime  # noqa: E402
from components import content_tools                            # noqa: E402
from components.agents import hots as hots_mod                  # noqa: E402

CLUB = "stage3_club"
FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def _setup() -> ContentRuntime:
    rt = ContentRuntime(base_dir=os.environ["STORAGE_BASE_DIR"])
    rt.seed_demo(CLUB)
    rt.scan_topics(CLUB)
    rt.draft(CLUB)
    rt.verify(CLUB)
    rt.platform_versions(CLUB, force=True)
    return rt


# ---------- T3.1 ----------
def test_experts():
    print("[T3.1] 6 角色阵容")
    experts = review_runtime.ReviewRuntime.experts()
    ids = [e["id"] for e in experts]
    check("阵容 6 角色", len(experts) == 6, ids)
    check("角色 id 与设计一致",
          ids == ["review_host", "fact_checker", "copy_editor",
                  "platform_operator", "compliance_reviewer", "impact_analyst"], ids)
    check("每个角色有中文显示名与职责",
          all(e.get("label") and e.get("desc") for e in experts), experts)
    from config import DEFAULT_CONFIG
    import copy as _copy
    cfg = _copy.deepcopy(DEFAULT_CONFIG)
    cfg.llm.api_key = cfg.llm.api_key or "sk-offline-test"
    spec = review_runtime._build_spec("rv_s3", {"node_id": "root", "kind": "root"},
                                      cfg, CLUB, {"materials": [], "draft": {}})
    agent_names = set(spec.agents.keys())
    check("团队规格含全部 6 角色",
          {"leader", "fact_checker", "copy_editor", "platform_operator",
           "compliance_reviewer", "impact_analyst"} <= agent_names, agent_names)
    check("名册含真人编辑位(HITT)",
          any(m.member_name == "human_agent" for m in spec.predefined_members),
          [m.member_name for m in spec.predefined_members])
    check("使用内容域工具 provider",
          any(getattr(t, "type", "") == "content_domain_read" for t in spec.agents["leader"].tools),
          spec.agents["leader"].tools)


# ---------- T3.1b: 内容稿复盘到底召集谁(走 API 这条路线) ----------
def test_content_dispatch():
    """内容稿(kind=draft)复盘必须召集六个采编角色, 而且支持只召集勾选的几个。

    这一条是回归: 之前这里落到了另一域的分支, 召集的是名册里根本没有的角色,
    那一轮复盘等于没开, 而界面上却看起来"团队在跑"。
    """
    print("[T3.1b] 内容稿复盘的角色召集(API 路线)")
    rt = review_runtime.get_review_runtime()
    ses = review_runtime.ReviewSession("rv_seq", CLUB, "t", "s", "draft:3",
                                       {"node_id": "draft:3", "kind": "draft"})
    ids = [x[0] for x in rt._expert_sequence(ses)]
    check("内容稿召集五个采编专家(主持另外汇总)",
          ids == ["fact_checker", "compliance_reviewer", "copy_editor",
                  "platform_operator", "impact_analyst"], ids)
    check("不再错叫名册外的角色",
          "resume_coach" not in ids and "score_coach" not in ids, ids)
    check("召集的每个角色都在 6 人名册里",
          all(i in review_runtime.EXPERT_LABELS for i in ids), ids)
    check("每个角色的任务提示都要求先读素材/清单/稿件再说话",
          all(("read_material_library" in p) or ("render_draft" in p)
              for _, _, p in review_runtime._CONTENT_EXPERT_SEQUENCE),
          [e for e, _, p in review_runtime._CONTENT_EXPERT_SEQUENCE
           if "read_material_library" not in p and "render_draft" not in p])
    ses.requested_roles = ["compliance_reviewer", "impact_analyst"]
    check("用户勾哪几个就只召集哪几个",
          [x[0] for x in rt._expert_sequence(ses)]
          == ["compliance_reviewer", "impact_analyst"],
          [x[0] for x in rt._expert_sequence(ses)])
    ses.requested_roles = ["review_host"]
    check("只勾主持时不召集任何专家(主持自己汇总)",
          rt._expert_sequence(ses) == [], rt._expert_sequence(ses))
    ses.requested_roles = None
    ses.node = {"node_id": "qa_1", "kind": "qa", "question": "q", "answer": "a"}
    check("交付物只保留内容域: 任何节点都召集采编专家, 没有其它分支",
          [x[0] for x in rt._expert_sequence(ses)]
          == ["fact_checker", "compliance_reviewer", "copy_editor",
              "platform_operator", "impact_analyst"],
          [x[0] for x in rt._expert_sequence(ses)])


# ---------- T3.2 ----------
async def test_tools(rt: ContentRuntime):
    print("[T3.2] 领域工具(素材库/待核实清单/稿件)")
    names = set()
    for t in (content_tools.read_material_library, content_tools.read_check_list,
              content_tools.render_draft, content_tools.retrieve_materials,
              content_tools.add_topic_bank):
        fn = getattr(t, "func", None) or getattr(t, "_func", None)
        names.add(getattr(fn, "__name__", "") or repr(t))
    check("工具名已换到内容域",
          names == {"read_material_library", "read_check_list", "render_draft",
                    "retrieve_materials", "add_topic_bank"}, names)

    mats = await content_tools.read_material_library.invoke({"club_id": CLUB, "limit": 5})
    check("read_material_library 返回素材并带权威度",
          mats["count"] == len(corpus.all_materials())
          and all("authority" in m for m in mats["materials"]), mats["count"])
    check("素材库带来源通道", all(m.get("source") for m in mats["materials"]))

    cl = await content_tools.read_check_list.invoke({"club_id": CLUB})
    check("read_check_list 返回待核实清单", len(cl["check_list"]) >= 1,
          cl.get("summary"))
    check("清单项含中文标签与阻断标记",
          all("label" in c and "blocking" in c for c in cl["check_list"]),
          cl["check_list"][:1])

    d = await content_tools.render_draft.invoke({"club_id": CLUB})
    check("render_draft 返回稿件全文与段结构",
          bool(d.get("text")) and len(d.get("segments") or []) >= 1, d.get("topic"))

    ret = await content_tools.retrieve_materials.invoke(
        {"club_id": CLUB, "query": "到场人数", "top_k": 3})
    check("retrieve_materials 返回检索结果", isinstance(ret.get("results"), list), ret)

    # 会话内读取**当时快照**(design/11 §9 T3.2)
    seq = rt.store_for(CLUB).head_seq
    snap = review_bridge.snapshot(CLUB, f"draft:{seq}")
    check("成稿节点快照可物化", "error" not in snap, snap.get("error"))
    check("快照含素材库/稿件/待核实清单",
          snap.get("materials") and snap.get("draft") is not None
          and "check_list" in snap, list(snap.keys())[:8])

    ses = review_runtime.ReviewSession("rv_s3", CLUB, "team", "sess_s3",
                                       f"draft:{seq}",
                                       {"node_id": f"draft:{seq}", "kind": "draft"},
                                       snapshot=snap, seq=seq)
    review_runtime.get_review_runtime()._sessions["rv_s3"] = ses
    review_runtime.get_review_runtime()._by_session["sess_s3"] = ses
    try:
        from openjiuwen.agent_teams.context import reset_session_id, set_session_id
        token = set_session_id("sess_s3")
        try:
            mats_snap = await content_tools.read_material_library.invoke({"club_id": CLUB})
            draft_snap = await content_tools.render_draft.invoke({"club_id": CLUB})
            cl_snap = await content_tools.read_check_list.invoke({"club_id": CLUB})
        finally:
            reset_session_id(token)
        check("会话内工具读的是当时快照",
              mats_snap.get("from_snapshot") is True
              and draft_snap.get("from_snapshot") is True
              and cl_snap.get("from_snapshot") is True,
              (mats_snap.get("from_snapshot"), draft_snap.get("from_snapshot")))
        check("快照素材数 = 当时 seq 的素材数",
              mats_snap["count"] == len(snap["materials"]), mats_snap["count"])
    finally:
        review_runtime.get_review_runtime()._sessions.pop("rv_s3", None)
        review_runtime.get_review_runtime()._by_session.pop("sess_s3", None)

    # 选题沉淀(换名后的 add_topic_bank)
    got = await content_tools.add_topic_bank.invoke(
        {"club_id": CLUB, "subject": "纳新宣讲会", "kind": "no_draft", "reason": "测试"})
    check("add_topic_bank 入库去重", "added" in got, got)


# ---------- T3.3 ----------
def test_hots(rt: ContentRuntime):
    print("[T3.3] 总编模式(命令 + payload 装填 + 产出护栏)")
    check("命令注册: re_verify/re_draft",
          hots_mod.script_for("re_verify") and hots_mod.script_for("re_draft"))
    check("旧命令名仍兼容", hots_mod.script_for("re_score") and hots_mod.script_for("re_question"))
    check("re_verify 脚本并行两个 worker",
          "parallel" in hots_mod.script_for("re_verify")
          and "compliance" in hots_mod.script_for("re_verify"))
    check("re_draft 脚本产出多平台",
          "platforms" in hots_mod.script_for("re_draft"))
    check("脚本带事实约束(不许编数据)",
          "不许" in hots_mod.script_for("re_draft") and "素材" in hots_mod.script_for("re_draft"))

    seq = rt.store_for(CLUB).head_seq
    snap = review_bridge.snapshot(CLUB, f"draft:{seq}")
    ses = review_runtime.ReviewSession("rv_s3b", CLUB, "team", "sess_s3b",
                                       f"draft:{seq}",
                                       {"node_id": f"draft:{seq}", "kind": "draft"},
                                       snapshot=snap, seq=seq)
    payload = review_runtime.ReviewRuntime._hots_payload(ses, "re_draft", {})
    check("payload 自动装填稿件全文", bool(payload.get("draft")), payload.get("draft", "")[:40])
    check("payload 自动装填待核实清单", bool(payload.get("check_list")))
    check("payload 自动装填素材库摘要", bool(payload.get("materials")))
    check("payload 带主题", bool(payload.get("topic")), payload.get("topic"))

    # 产出护栏: 篡改事实的多平台版本必须被标为不合格
    guard = {"platforms": {
        "wechat": payload["draft"],                        # 原文 → 应当通过
        "poster": "11月20日在大学生活动中心举办, 到场300人。",  # 改了地点与人数 → 应当不通过
    }, "segments": []}
    res = asyncio.run(review_runtime.ReviewRuntime()._attach_hots_guard(
        ses, "re_draft", payload, guard))
    check("护栏逐平台做断言级 diff",
          res.get("platform_ok") is False
          and res["platform_diff"]["wechat"]["ok"] is True
          and res["platform_diff"]["poster"]["ok"] is False,
          res.get("platform_diff"))
    check("护栏给出违规说明",
          any("数字" in v or "场地" in v for v in
              res["platform_diff"]["poster"]["violations"]),
          res["platform_diff"]["poster"]["violations"])
    check("总编模式产出带免责说明", "系统核验" in res.get("disclaimer", ""),
          res.get("disclaimer"))

    vres = asyncio.run(review_runtime.ReviewRuntime()._attach_hots_guard(
        ses, "re_verify", payload, {"claims": []}))
    check("核验结论标注为证据意见(不下审核结论)",
          "审核结论由人作出" in vres.get("disclaimer", ""), vres.get("disclaimer"))


# ---------- T3.4 ----------
async def test_sse_and_recover(rt: ContentRuntime):
    print("[T3.4] SSE 流契约与会话重建")
    from components.review_runtime import ReviewRuntime
    ses = ReviewSessionStub = review_runtime.ReviewSession(
        "rv_s3c", CLUB, "team", "sess_s3c", f"draft:{rt.store_for(CLUB).head_seq}",
        {"node_id": "root", "kind": "draft"},
        snapshot=review_bridge.snapshot(CLUB, "root"), seq=rt.store_for(CLUB).head_seq)

    # ChunkBus: 事件发布/订阅与历史回放(前端 SSE 的数据源)
    import asyncio as _a
    queue = await ses.bus.subscribe()          # 订阅时先回放 backlog(中途加入不漏消息)
    await ses.bus.publish({"type": "chunk", "payload": {"sender": "fact_checker",
                                                       "body": "第一句"}})
    await ses.bus.publish({"type": "hots_result",
                           "payload": {"command": "re_verify", "ok": True}})
    got = [_a.wait_for(queue.get(), timeout=2) for _ in range(2)]
    got = await _a.gather(*got)
    check("SSE 事件可流式消费(订阅 + 回放)",
          len(got) == 2 and got[0]["type"] in ("chunk", "hots_result"), got)
    check("事件是 JSON 友好结构(可直接 SSE 序列化)",
          isinstance(json.dumps(got[0], ensure_ascii=False), str))
    await ses.bus.close()
    sentinel = await _a.wait_for(queue.get(), timeout=2)
    check("关闭时投递结束哨兵(前端据此收流)", sentinel is None, sentinel)
    check("会话可落盘重建(COLD_RECOVER 的元数据基础)",
          isinstance(ses.to_record(), dict) and ses.to_record().get("review_id") == "rv_s3c",
          list(ses.to_record().keys())[:6])
    check("会话状态可查", ses.status in ("starting", "running", "idle", "closed"),
          ses.status)
    check("6 角色状态可查", len(ses.experts_status()) == 6,
          [e["id"] for e in ses.experts_status()])


def main():
    try:
        rt = _setup()
        test_experts()
        test_content_dispatch()
        asyncio.run(test_tools(rt))
        test_hots(rt)
        # A3: 起一场采编复盘(离线只验证节点与名册; 真实团队会话需 Key)
        rt.draft(CLUB)                       # 再成一次稿, 让最新成稿节点对齐当前 head
        graph = review_graph.build_graph(CLUB)
        node_id = (graph["nodes"] or [{}])[-1].get("node_id") or "root"
        node = review_graph.get_node(CLUB, node_id)
        check("A3: 成稿节点可被复盘(节点图含稿件节点)",
              node is not None and node.get("kind") == "draft", (node_id, node and node.get("kind")))
        check("A3: 节点图含 root 与稿件节点",
              graph["root"]["kind"] == "root"
              and any(n["kind"] == "draft" for n in graph["nodes"]),
              [(n["node_id"], n["kind"]) for n in graph["nodes"]])
        check("A3: 复盘菜单可列会话", isinstance(
            review_runtime.get_review_runtime().list_reviews(CLUB), dict))
        asyncio.run(test_sse_and_recover(rt))
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
    if FAILS:
        print("\n阶段3 智能体相测试 FAILED: %d 项" % len(FAILS))
        raise SystemExit(1)
    print("\n阶段3 智能体相测试 PASSED")


if __name__ == "__main__":
    main()
