# coding: utf-8
"""_check_workbench_frontend.py — 三栏工作台前端静态契约校验(对照 test/_check_frontend.py)。

校验四件事(全部可离线跑, 零 LLM):

1. `static/workbench.js` 里出现的每个 `/api/content/*` 路径**真实存在于 server.py 路由表**
   (逐个比对 Starlette app.routes, 不是查字符串);
2. `workbench.html` / `workbench.js` 引用的 DOM id 都在 html 里; 内联 onclick 调用的
   `WBS.*` 方法都在 js 里导出;
3. html 引用的静态资源(style.css / workbench.css / workbench.js)都在磁盘上;
4. 页面带的进程令牌用法与 index.html 一致(`__AUTH_TOKEN__` + `X-Auth-Token` 头)。

用法:
    D:\\jiuwen\\Scripts\\python.exe test\\_check_workbench_frontend.py
退出码 0 = 全通过; 1 = 有 FAIL。
"""
import os
import re
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _HERE)

os.environ.setdefault("EMBEDDING_OFF", "1")
os.environ.setdefault("LLM_GATE_MODE", "auto_deny")
os.environ.setdefault("TOPIC_STORE_BACKEND", "file")

_STATIC = os.path.join(_HERE, "static")
FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def read(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def server_routes():
    """从 server.py 的 Starlette app 取路由表(路径 → 允许的方法)。"""
    import server
    table = {}
    for r in server.app.routes:
        path = getattr(r, "path", None)
        if not path:
            continue
        methods = getattr(r, "methods", None) or set()
        table.setdefault(path, set()).update(methods)
    return table


def main():
    html = read(os.path.join(_STATIC, "workbench.html"))
    js = read(os.path.join(_STATIC, "workbench.js"))

    print("[1] JS 引用的 /api/content/* 路由必须存在于 server.py 路由表")
    routes = server_routes()
    # js 里的路径既有字面量("/api/content/seed_demo")也有 API 表里的键值
    api_paths = set(re.findall(r'"(/api/content/[a-z_]+)"', js))
    api_paths |= set(re.findall(r"'(/api/content/[a-z_]+)'", js))
    api_paths |= set(re.findall(r'"(/api/content/[a-z_]+)\?', js))
    api_paths = sorted(api_paths)
    print("  js 引用路径 %d 条: %s" % (len(api_paths), ", ".join(api_paths)))
    missing = [p for p in api_paths if p not in routes]
    check("每个 /api/content/* 路径都在 server.py 路由表里", not missing, missing)
    check("工作台路由 /workbench 已注册", "/workbench" in routes,
          sorted(k for k in routes if "work" in k))
    # 采编复盘面板走 /api/review/*(团队/SSE): 也逐个比对路由表, 不靠字符串猜
    review_paths = sorted(set(re.findall(r'"(/api/review/[a-z_]+)"', js))
                          | set(re.findall(r"'(/api/review/[a-z_]+)'", js)))
    review_missing = [p for p in review_paths if p not in routes]
    check("采编复盘引用的 /api/review/* 都在路由表里", not review_missing,
          review_missing)
    check("除内容域外只额外用了 /api/review/*(不越域乱调)",
          all(p.startswith("/api/content/") for p in api_paths)
          and all(p.startswith("/api/review/") for p in review_paths),
          [p for p in api_paths if not p.startswith("/api/content/")])
    # 契约表(任务书)里列出的 17 条必须全部被前端用上, 少一条就是漏了功能
    required = {
        "/api/content/seed_demo", "/api/content/analyze", "/api/content/ingest",
        "/api/content/state", "/api/content/gaps", "/api/content/checklist",
        "/api/content/topics", "/api/content/draft", "/api/content/verify",
        "/api/content/platforms", "/api/content/rollback", "/api/content/versions",
        "/api/content/resolve_conflict", "/api/content/dashboard",
        "/api/content/review_record", "/api/content/review_export",
        "/api/content/export_package",
        # 改版新增: 三渠道实时预览 + 六角色辅助(都是零 LLM 的确定性接口)
        "/api/content/preview", "/api/content/assist", "/api/content/assist_roles",
    }
    check("契约里的内容域接口全部被前端调用", required <= set(api_paths),
          sorted(required - set(api_paths)))
    # 账号与 API 配置(右上角设置)也是 /api 调用, 一并比对路由表
    user_paths = sorted(set(re.findall(r'"(/api/(?:auth|user)/[a-z_]+)"', js)))
    check("设置面板引用的 /api/auth|/api/user 都在路由表里",
          not [p for p in user_paths if p not in routes],
          [p for p in user_paths if p not in routes])

    print("[2] DOM id / 内联 onclick 处理器")
    html_ids = set(re.findall(r'id="([^"]+)"', html))
    js_ids = (set(re.findall(r"\$\('([^']+)'\)", js))
              | set(re.findall(r"\$\(\"([^\"]+)\"\)", js))
              | set(re.findall(r"getElementById\('([^']+)'\)", js)))
    # 运行期自建的节点(提示条)不算缺失: 认 el.id = "..." 这类赋值
    js_ids -= set(re.findall(r'\.id = "([^"]+)"', js))
    missing_ids = sorted(js_ids - html_ids)
    print("  html id 数: %d; js 引用 id 数: %d" % (len(html_ids), len(js_ids)))
    check("js 引用的 DOM id 都在 html 里", not missing_ids, missing_ids)

    onclick = set(re.findall(r'onclick="WBS\.([A-Za-z0-9_]+)\s*\(', html))
    onclick |= set(re.findall(r"onclick=\"WBS\.([A-Za-z0-9_]+)\s*\(", js))
    # 导出块里允许一行写多个 "名字: 名字,"（这版为了压行数就这么写的），所以不能按
# "整行只有一个键值对"来匹配 —— 逐个键值对抽，别要求行首行尾。
    exported = set(re.findall(r"([A-Za-z0-9_]+):\s*([A-Za-z0-9_]+)\s*,", js))
    exported |= set(re.findall(r"([A-Za-z0-9_]+):\s*([A-Za-z0-9_]+)\s*\n", js))
    exported = {k for k, v in exported if k == v}
    missing_fn = sorted(f for f in onclick if f not in exported)
    print("  内联处理器: %s" % ", ".join(sorted(onclick)))
    check("内联 onclick 的 WBS.* 方法都在 js 里导出", not missing_fn, missing_fn)
    # 拖拽/键盘这些"看不见的入口"必须存在, 否则界面只剩输入框
    for fn in ("startDrag", "resolveDrop", "applyDrop", "bindKeyboard", "bindBoardDrag",
               "startAssist", "renderPreview"):
        check("js 里有 %s" % fn, ("function %s(" % fn) in js)

    print("[3] 静态资源与样式")
    for res in re.findall(r'(?:href|src)="static/([^"]+)"', html):
        check("static/%s 存在" % res, os.path.exists(os.path.join(_STATIC, res)))
    css = read(os.path.join(_STATIC, "workbench.css"))
    html_ids = set(re.findall(r'id="([^"]+)"', html))
    classes = set()
    for attr in re.findall(r'(?<![\w-])class="([^"]+)"', html):
        for part in attr.split():
            if re.match(r"^(wb|badge|b|g)-", part):
                classes.add(part)
    # js 动态拼出来的类名也算(排除那些其实是被引号包起来的 DOM id)
    dyn = set(re.findall(r'"((?:wb|badge|b|g)-[a-z0-9-]+)"', js))
    dyn |= set(re.findall(r"'((?:wb|badge|b|g)-[a-z0-9-]+)'", js))
    dyn -= set(re.findall(r'\.id = "([^"]+)"', js))     # 运行期自建节点的 id, 不是类
    classes |= {c for c in dyn if c not in html_ids}
    defined = set(re.findall(r"\.([a-zA-Z][a-zA-Z0-9_-]*)", css))
    undefined = sorted(c for c in classes if c not in defined)
    check("用到的 wb- 类都在 workbench.css 里定义", not undefined, undefined)
    check("workbench.css 不改动 style.css(只新增文件)",
          os.path.exists(os.path.join(_STATIC, "workbench.css")))
    # 右栏内部是"上下各占 50%"的稳定分栏: 智能辅助最多一半, 三渠道预览不被挤没
    ai_rule = re.search(r"\.wb-ai\s*\{([^}]*)\}", css)
    pv_rule = re.search(r"\.wb-pv\s*\{([^}]*)\}", css)
    check("智能辅助限高在右栏 50%（max-height: 50%）",
          bool(ai_rule) and re.search(r"max-height:\s*50%", ai_rule.group(1)) is not None,
          ai_rule.group(1).strip()[:80] if ai_rule else None)
    check("三渠道预览拿另一半（flex: 1 1 50%）",
          bool(pv_rule) and re.search(r"flex:\s*\d+\s+\d+\s+50%", pv_rule.group(1)) is not None,
          pv_rule.group(1).strip()[:80] if pv_rule else None)
    check("窄屏从 50% 分栏退回自然高度（max-height: none）",
          re.search(r"@media \(max-width: 1140px\)[\s\S]*?\.wb-ai\s*\{[^}]*max-height:\s*none",
                    css) is not None)

    print("[4] 进程令牌用法(与 index.html 一致)")
    check("html 内联注入 __AUTH_TOKEN__", "__AUTH_TOKEN__" in html)
    check("js 所有 /api 请求带 X-Auth-Token 头", "X-Auth-Token" in js)
    check("直接开静态文件时回退 window.__AUTH__", "__AUTH__" in js)
    check("导出下载也带令牌(fetch + blob, 不用裸 a[href])",
          "URL.createObjectURL" in js and "X-Auth-Token\": authToken()" in js)
    check("没有引入构建产物/CDN(script/link 全指向本地 static)",
          not re.search(r'(?:src|href)="https?://', html)
          and "require(" not in js and "node_modules" not in html + js
          and not re.search(r"^\s*import\s", js, re.M))

    print("[5] 零 LLM 可演示(不出现『必须配 Key 才能用』的死路)")
    check("没有 use_llm=true 的硬依赖调用", "use_llm" not in js)
    # 改版后 API Key 只在「设置」里配: 允许出现输入框, 但不许成为主线的前置条件。
    check("填 Key 之前没有硬门禁(辅助/预览不检查 Key)",
          "api_key" not in js.lower() or
          all(("api_key" not in seg) for seg in
              [js.split("function startAssist")[1].split("function askAi")[0],
               js.split("function refreshPreview")[1].split("function renderPreview")[0]]),
          "startAssist/refreshPreview 里不该出现 api_key")
    check("确定性降级有明说的文案",
          "确定性" in js and "没配" in js)

    print("[6] node --check(可用则算通过; 不可用则跳过)")
    import shutil
    import subprocess
    node = shutil.which("node")
    if not node:
        print("  skip node 不在 PATH, 跳过 JS 语法检查")
    else:
        p = subprocess.run([node, "--check", os.path.join(_STATIC, "workbench.js")],
                           capture_output=True, text=True)
        check("node --check static/workbench.js", p.returncode == 0,
              (p.stderr or p.stdout)[:400])
        print("  node 版本: %s" % subprocess.run(
            [node, "--version"], capture_output=True, text=True).stdout.strip())

    print("")
    if FAILS:
        print("FAILED(%d): %s" % (len(FAILS), "; ".join(FAILS)))
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
