/* test/_test_docboard_dom.mjs — 在 Node 里真跑 static/workbench.js，钉住这一版交互主线。
 *
 * 这一版（用户明确要求的版式）钉的是:
 *
 *   [1] 积木流模型(纯逻辑): 先到在上 / 插入按落点 / 移动 / 拿掉 / 一块=一段 segments
 *   [2] 中栏渲染: 每块是 .wb-brick, 带来源徽章与"✕ 拿掉", 不预设段落结构
 *   [3] 拖拽主线: 左栏素材 → 中栏 → **左栏那条素材消失**(用掉了)
 *   [4] 收回: 点 ✕ 或拖回左栏 → 素材回池子
 *   [5] 键盘等价路径: Alt+↑/↓ 挪位、Delete 拿掉(鼠标不灵也能用)
 *   [6] 六个角色: 多选 → 启动智能辅助 → 右栏逐条滚出意见
 *   [7] 应用建议: 带 action 的意见点「应用」真的改稿(并明确说改动了几处)
 *   [8] 三渠道预览: 订阅号/短视频/海报并排渲染, 海报三槽位缺哪个都看得见
 *   [9] 设置: 登录表单 + API 配置入口存在, 登录会打到 /api/auth/login
 *  [10] 命令面板 / 主题 / 顶部按钮精简
 *
 * 用法: node test/_test_docboard_dom.mjs
 */
import fs from "node:fs";
import path from "node:path";
import { createDom } from "./_wb_dom_shim.mjs";

const HERE = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1"));
const ROOT = path.dirname(HERE);
const STATIC = path.join(ROOT, "static");
const FIXTURES = process.argv[2] ||
  path.join(ROOT, "data", "_probe_workbench_tmp", "shapes.json");
if (!fs.existsSync(FIXTURES)) {
  console.error("缺少 API 快照: " + FIXTURES +
    "\n请先跑: D:\\jiuwen\\Scripts\\python.exe test\\_probe_workbench_api.py");
  process.exit(2);
}

const fails = [];
function check(name, cond, detail) {
  if (cond) console.log("  ok   " + name);
  else {
    console.log("  FAIL " + name + "  " + (detail === undefined ? "" : JSON.stringify(detail)));
    fails.push(name);
  }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------------- 1) 模型层（纯逻辑，不碰 DOM） ---------------- */
const boardSrc = fs.readFileSync(path.join(STATIC, "doc-board.js"), "utf8");
const tmp = { window: {} };
new Function("window", boardSrc)(tmp.window);
const Doc = tmp.window.WBDoc;

console.log("[1] 积木流模型");
{
  const d = Doc.createDoc({});
  d.insert({ text: "第一条", eid: "evt_1", whole: true });
  d.insert({ text: "第二条", eid: "evt_2", si: 0 });
  d.insert({ text: "第三条", eid: "evt_3", si: 1 });
  check("先到在上：插入顺序就是阅读顺序",
    d.blocks.map((b) => b.text).join("|") === "第一条|第二条|第三条",
    d.blocks.map((b) => b.text));
  check("块数 / 有来源块数正确", d.count() === 3 && d.sourcedCount() === 3,
    [d.count(), d.sourcedCount()]);

  d.insert({ text: "插在最前面", eid: "evt_4" }, 0);
  check("按落点 index 插入（插到最前）", d.blocks[0].text === "插在最前面",
    d.blocks[0].text);

  const uid2 = d.blocks[1].uid;                    // 第一条
  d.move(uid2, 3);
  check("挪到指定位（落点 index = 挪完之后它所在的位置）",
    d.blocks[3].text === "第一条", d.blocks.map((b) => b.text));
  d.move(uid2, { index: 0 });
  check("也能挪回最前面", d.blocks[0].text === "第一条", d.blocks.map((b) => b.text));

  const gone = d.remove(d.blocks[0].uid);
  check("拿掉一块返回它本身（素材可以回池子）", !!gone && d.count() === 3, gone && gone.text);

  const segs = d.toSegments();
  check("一块 = 一段：seg_id 按下标稳定生成",
    segs.length === 3 && segs[1].seg_id === "blk_2", segs.map((s) => s.seg_id));
  check("segments 的 source_refs 与块的 eid 一一对应（核验据它溯源）",
    segs.map((s) => s.source_refs[0]).join(",") ===
      d.blocks.map((b) => b.eid).join(","),
    [segs.map((s) => s.source_refs[0]), d.blocks.map((b) => b.eid)]);

  const d2 = Doc.createDoc({});
  d2.fromSegments([
    { seg_id: "s1", kind: "lead", text: "第一句。第二句。", source_refs: ["evt_9"] },
    { seg_id: "s2", kind: "process", text: "第三句。", source_refs: ["evt_8"] },
  ]);
  check("系统稿的段 → 逐句拆成积木块（不保留段结构）", d2.count() === 3, d2.count());
  check("系统稿的块标 from=system（界面要能分辨来源）",
    d2.blocks.every((b) => b.from === "system"));
  check("系统稿只在段级知道来源，句级按顺序摊派",
    d2.blocks[0].eid === "evt_9" && d2.blocks[2].eid === "evt_8",
    d2.blocks.map((b) => b.eid));

  d2.markVerify({ segments: [
    { seg_id: "blk_1", block: true, gaps: [{ weakness_type: "no_source" }] },
    { seg_id: "blk_2", block: false, gaps: [] },
  ] });
  check("核验结果按位置挂回块（blocked / verified）",
    d2.blocks[0].status === "blocked" && d2.blocks[1].status === "verified",
    d2.blocks.map((b) => b.status));
}

/* ---------------- 2) 渲染 + 拖拽（真跑 workbench.js） ---------------- */
const fixtures = JSON.parse(fs.readFileSync(FIXTURES, "utf8"));
const calls = [];
let failTeam = false;      // 置真 = 模拟"团队起不来"(Key 无效 / 闸门全拒 / 网络不通)
function replyFor(url, body) {
  const u = String(url);
  const has = (k) => u.includes(k);
  if (has("/api/auth/me")) return { ok: false, username: "" };
  if (has("/api/user/llm/test")) return { ok: false, error: "没填 API Key" };
  if (has("/api/user/llm")) return { ok: true, logged_in: false, configured: false,
    api_base: "https://api.deepseek.com", model_name: "deepseek-v4-flash", provider: "openai" };
  if (has("/api/auth/login")) return { ok: true, token: "u-token", username: "测试" };
  if (has("/api/auth/register")) return { ok: true, token: "u-token", username: "测试" };
  if (has("/api/auth/logout")) return { ok: true };
  if (has("/api/content/assist_roles")) return fixtures.assist_roles;
  if (has("/api/content/preview")) return fixtures.preview;
  if (has("/api/content/review") && !has("/api/content/review_")) {
    if (failTeam) return { error: "model service config error, reason: api_key is required" };
    return { review_id: "rv_shim", node_id: "draft:6", status: "starting", roles: body && body.roles };
  }
  if (has("/api/content/assist")) {
    // 只跑被点名的角色：按请求里的 roles 过滤，模拟服务端行为
    const want = (body && body.roles) || fixtures.assist.roles;
    const keep = fixtures.assist.messages.filter((m) => want.includes(m.role));
    return { ...fixtures.assist, roles: want, messages: keep.length ? keep : fixtures.assist.messages };
  }
  if (has("/api/content/state")) return fixtures.state;
  if (has("/api/content/checklist")) return fixtures.checklist;
  if (has("/api/content/versions")) {
    if (u.includes("seq=")) return fixtures.versions.current;
    return fixtures.versions;
  }
  if (has("/api/content/gaps")) return fixtures.gaps;
  if (has("/api/content/verify")) return fixtures.verify || fixtures.gaps;
  if (has("/api/content/draft")) return fixtures.draft;
  if (has("/api/content/platforms")) return fixtures.platforms_force;
  if (has("/api/content/dashboard")) return fixtures.dashboard;
  if (has("/api/content/review_record")) return fixtures.review_record;
  if (has("/api/review/experts")) {
    return { experts: [
      { id: "review_host", label: "采编主持", desc: "汇总" },
      { id: "fact_checker", label: "事实核查员", desc: "核依据" },
    ] };
  }
  return { ok: true };
}

const { document, root, byId } = createDom(
  fs.readFileSync(path.join(STATIC, "workbench.html"), "utf8"));

// 让垫片里的元素知道自己的 document：事件冒泡到 document 时用得上
(function attach(el) {
  el.ownerDocument = document;
  el.childNodes.forEach((c) => { if (c.nodeType === 1) attach(c); });
})(root);
document.elementFromPoint = (x, y) => {
  let hit = null;
  (function walk(el) {
    el.childNodes.forEach((c) => {
      if (c.nodeType !== 1) return;
      // 只认测试显式摆放过的元素：没摆放的没有可信几何，一律跳过
      if (c.placed) {
        const r = c.getBoundingClientRect();
        if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) hit = c;
      }
      walk(c);
    });
  })(root);
  return hit;
};

const listeners = {};
const window = {
  AUTH_TOKEN: "shim-token", innerWidth: 1600, innerHeight: 900,
  confirm: () => true,
  addEventListener: (t, fn) => { (listeners[t] = listeners[t] || []).push(fn); },
  removeEventListener: (t, fn) => {
    const list = listeners[t] || [];
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  },
  URL: { createObjectURL: () => "blob:x", revokeObjectURL() {} },
  EventSource: class { constructor() { this.readyState = 1; } close() {} }
};
globalThis.window = window;
globalThis.document = document;
globalThis.NodeFilter = { SHOW_TEXT: 4 };
globalThis.URLSearchParams = URLSearchParams;
globalThis.Blob = class { constructor(p) { this.parts = p; } };
globalThis.EventSource = window.EventSource;
globalThis.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
globalThis.sessionStorage = { getItem: () => null, setItem() {} };
globalThis.fetch = async (url, opts) => {
  const body = opts && opts.body ? JSON.parse(opts.body) : null;
  calls.push({ url: String(url), method: (opts && opts.method) || "GET",
    headers: (opts && opts.headers) || {}, body: body });
  return { ok: true, status: 200, text: async () => JSON.stringify(replyFor(url, body)) };
};

for (const f of ["doc-board.js", "links.js", "workbench.js"]) {
  const src = fs.readFileSync(path.join(STATIC, f), "utf8");
  new Function("window", "document", "globalThis", src)(window, document, globalThis);
}
const WBS = window.WBS;

// 垫片里事件分发是"元素自己往上冒泡"（没有全局 dispatch）：用 document.body 触发，
// 就能同时命中挂在 document.body 与 document 上的监听器（拖拽/键盘就是这么绑的）。
const fire = (type, init) => root.fire(type, init);

await sleep(60);
WBS.seedForTest(fixtures);
const doc = () => WBS.state.doc;
const bricks = () => root.querySelectorAll(".wb-brick");
const mats = () => root.querySelectorAll(".wb-mat");

console.log("[2] 中栏渲染（不预设段落结构）");
{
  check("系统稿渲染成积木块（一行一块 .wb-brick）", bricks().length >= 6, bricks().length);
  check("没有任何段落/槽位结构残留",
    root.querySelectorAll(".wb-group").length === 0 &&
    root.querySelectorAll(".wb-slot").length === 0 &&
    root.querySelectorAll(".wb-group-kind").length === 0);
  check("每块带来源徽章", root.querySelectorAll(".wb-brick-ref").length === bricks().length);
  check("每块带「拿掉」按钮 ✕", root.querySelectorAll(".wb-brick-x").length === bricks().length);
  check("块号从 1 连续", root.querySelectorAll(".wb-brick-no")
    .map((n) => n.textContent).join(",") === bricks().map((_, i) => i + 1).join(","),
    root.querySelectorAll(".wb-brick-no").map((n) => n.textContent));
  check("正文用阅读字号（.wb-brick-txt 走 --read-size）",
    fs.readFileSync(path.join(STATIC, "workbench.css"), "utf8")
      .includes(".wb-brick-txt") &&
    fs.readFileSync(path.join(STATIC, "workbench.css"), "utf8")
      .match(/\.wb-brick-txt\s*\{[^}]*--read-size/));
}

console.log("[3] 拖拽主线：左栏素材 → 中栏，左栏那条消失");
{
  const before = bricks().length;
  const card = mats()[0];
  const eid = card.dataset.eid;
  const psent = card.querySelector(".wb-psent");
  const si = psent.dataset.si;
  const sentText = card.querySelector(".wb-psent-txt").textContent;
  const psentBefore = card.querySelectorAll(".wb-psent").length;

  // 落点放在中栏第一块的上半部分 → 插到最前面
  const first = bricks()[0];
  first.place(400, 100, 400, 40);
  byId.get("wb-boardwrap").place(380, 80, 460, 600);
  byId.get("wb-mat-list").place(0, 0, 300, 700);

  // 先走真实指针链路（垫片的 elementFromPoint + 事件冒泡都是真的）
  psent.fire("pointerdown", { clientX: 40, clientY: 20 });
  fire("pointermove", { clientX: 500, clientY: 105 });
  fire("pointerup", { clientX: 500, clientY: 105 });
  const viaPointer = doc().blocks[0] && doc().blocks[0].text === sentText;
  if (!viaPointer) {
    WBS.dropForTest({ from: "pool", text: sentText,
      block: { text: sentText, eid: eid, si: Number(si), from: "material" } }, 500, 105);
  }
  console.log("     （本次走的是" + (viaPointer ? "真实指针链路" : "dropForTest 兜底") + "）");
  check("拖拽主线生效（真实指针链路优先）", !!doc().blocks[0] &&
    doc().blocks[0].text === sentText, doc().blocks[0] && doc().blocks[0].text);
  check("拖入后稿子多了一块", bricks().length === before + 1, [before, bricks().length]);
  check("先到在上：落点在首块上半 → 插到最前面", doc().blocks[0].text === sentText);
  check("拖进来的块自带来源（溯源是组装的结果）", doc().blocks[0].eid === eid);

  // 左栏那条素材的这一句必须从池子里消失
  const cardAfter = mats().find((m) => m.dataset.eid === eid);
  const stillThere = cardAfter ? cardAfter.querySelectorAll(".wb-psent")
    .some((p) => p.dataset.si === si) : false;
  check("**用掉的那一句从左栏消失了**", !stillThere, { eid, si });
  if (psentBefore > 1) {
    check("同一条素材剩下的分句还在（只收起用掉的那句）",
      !!cardAfter && cardAfter.querySelectorAll(".wb-psent").length === psentBefore - 1,
      cardAfter && cardAfter.querySelectorAll(".wb-psent").length);
  }

  // 整条素材拖进来 → 那张卡整个从池子里消失
  const card2 = mats()[0];
  const eid2 = card2.dataset.eid;
  WBS.dragMaterialForTest(eid2, true);
  check("整条素材拖进来后，左栏不再有这张卡",
    !mats().some((m) => m.dataset.eid === eid2), eid2);
  check("整条素材落成一块（不按句拆开）",
    doc().blocks.filter((b) => b.eid === eid2 && b.whole).length === 1,
    doc().blocks.filter((b) => b.eid === eid2).map((b) => b.whole));
  check("拖拽光标与跟随影子都清理干净",
    byId.get("wb-dropmark").classList.contains("hidden") &&
    !String(root.innerHTML).includes("wb-ghost"));
}

console.log("[4] 收回：素材回池子");
{
  const n = bricks().length;
  const poolBefore = mats().length;
  const firstBrick = bricks()[0];
  const eid = firstBrick.dataset.eid;
  firstBrick.querySelector(".wb-brick-x").click();
  check("点 ✕ 后稿子少一块", bricks().length === n - 1, [n, bricks().length]);
  check("拿掉的素材回到左栏", mats().length >= poolBefore, [poolBefore, mats().length]);
  if (eid) {
    check("回池的是同一条素材", mats().some((m) => m.dataset.eid === eid), eid);
  }
  // 拖回左栏 = 拿掉
  const before2 = bricks().length;
  const uid = bricks()[0].dataset.uid;
  WBS.dropForTest({ from: "doc", uid: uid, text: "" }, 60, 60);
  check("拖到左栏也等于拿掉", bricks().length === before2 - 1,
    [before2, bricks().length]);
}

console.log("[5] 键盘等价路径（鼠标不灵时的兜底）");
{
  const uids = bricks().map((b) => b.dataset.uid);
  const second = bricks()[1];
  second.querySelector(".wb-brick-ref").click();       // 选中这一块
  check("点来源徽章会选中这一块", WBS.state.selected &&
    WBS.state.selected.uid === uids[1]);
  fire("keydown", { key: "ArrowUp", altKey: true, target: root, preventDefault() {} });
  const after = bricks().map((b) => b.dataset.uid);
  check("Alt+↑ 让选中的块往前挪一位",
    after.indexOf(uids[1]) === after.indexOf(uids[0]) - 1, [uids.slice(0, 2), after.slice(0, 2)]);
  fire("keydown", { key: "Delete", target: root, preventDefault() {} });
  check("Delete 拿掉选中的块",
    bricks().map((b) => b.dataset.uid).indexOf(uids[1]) < 0);
}

console.log("[6] 六个角色 → 启动智能辅助（右栏逐条滚出）");
{
  const roles = root.querySelectorAll(".wb-role");
  check("中栏下半列出 6 个角色", roles.length === 6, roles.length);
  check("默认一个都没选（用户自己组合）",
    byId.get("wb-role-count").textContent === "未选", byId.get("wb-role-count").textContent);
  WBS.setRolesForTest(["fact_checker", "compliance_reviewer", "copy_editor"]);
  check("勾上 3 个 → 计数与高亮同步",
    byId.get("wb-role-count").textContent === "3/6 已选" &&
    root.querySelectorAll(".wb-role.on").length === 3,
    byId.get("wb-role-count").textContent);

  byId.get("wb-ai-log").innerHTML = "";
  await WBS.startAssist();
  await sleep(1400);                                  // 等逐条滚出的节流走完
  const msgs = byId.get("wb-ai-log").querySelectorAll(".wb-ai-msg");
  check("右栏滚出各角色的意见（≥3 条）", msgs.length >= 3, msgs.length);
  check("每条意见带角色名", msgs.every((m) => m.querySelector(".wb-ai-who")));
  check("意见注明是确定性实现（不假装是大模型）",
    byId.get("wb-ai-log").textContent.includes("确定性"));
  check("只跑勾上的角色（不多跑）",
    root.querySelectorAll(".wb-ai-who").map((w) => w.textContent)
      .every((t) => ["事实核查员", "合规风险审查", "文案编辑"].includes(t)),
    root.querySelectorAll(".wb-ai-who").map((w) => w.textContent));
  const assistCall = calls.filter((c) => c.url.includes("/api/content/assist")).pop();
  check("请求里带上了选中的角色", assistCall &&
    JSON.stringify(assistCall.body.roles) ===
      JSON.stringify(["fact_checker", "compliance_reviewer", "copy_editor"]),
    assistCall && assistCall.body.roles);
  check("请求里带上当前积木流的 segments（一块一段）",
    assistCall && assistCall.body.segments.length === bricks().length);
}

console.log("[6.1] 配好 API 后同一个按钮改走团队路线（不是确定性）");
{
  const before = calls.length;
  WBS.state.llmReady = true;
  await WBS.startAssist();
  await sleep(60);
  const team = calls.slice(before).filter((c) => c.url.includes("/api/content/review"));
  check("有 Key 时点「启动智能辅助」走 /api/content/review（API 多智能体）",
    team.length === 1, calls.slice(before).map((c) => c.url));
  check("团队路线把勾选的角色带过去",
    team.length === 1 && Array.isArray(team[0].body.roles) && team[0].body.roles.length === 3,
    team[0] && team[0].body.roles);
  check("右栏状态注明走的是团队(API)",
    byId.get("wb-ai-state").textContent.includes("团队"), byId.get("wb-ai-state").textContent);
  if (WBS.state.review.watchdog) clearTimeout(WBS.state.review.watchdog);
  WBS.state.review.id = null;
  WBS.state.llmReady = false;        // 后面几节回到确定性路线
}

console.log("[6.2] 团队起不来 → 明说原因再降级（不让人卡在转圈按钮上）");
{
  // 模拟"配了 Key 但团队起不来"（Key 无效 / 闸门全拒 / 网络不通）
  const before = calls.length;
  failTeam = true;
  WBS.state.llmReady = true;
  byId.get("wb-ai-log").innerHTML = "";
  await WBS.startAssist();
  await sleep(1200);                 // 等降级后的确定性消息滚完
  const teamCall = calls.slice(before).filter((c) => c.url.includes("/api/content/review"))[0];
  const detCall = calls.slice(before).filter((c) => c.url.includes("/api/content/assist"))[0];
  check("先试了团队路线", !!teamCall, calls.slice(before).map((c) => c.url));
  check("团队报错后自动改走确定性接口", !!detCall, calls.slice(before).map((c) => c.url));
  const log = byId.get("wb-ai-log").textContent;
  check("界面上明说了降级原因与去向",
    log.includes("改走确定性版本") && log.includes("团队"), log.slice(0, 160));
  check("降级后仍然给出了意见（不是空着）",
    byId.get("wb-ai-log").querySelectorAll(".wb-ai-msg").length >= 3,
    byId.get("wb-ai-log").querySelectorAll(".wb-ai-msg").length);
  check("降级后状态栏写明走的是确定性",
    byId.get("wb-ai-state").textContent.includes("确定性"),
    byId.get("wb-ai-state").textContent);
  failTeam = false;
  WBS.state.llmReady = false;
}

console.log("[6.3] 团队启动慢 ≠ 失败：不能抢跑降级（这一版踩过的坑）");
{
  // 场景: 团队正常，但"起团队 + 主持注册名册 + 第一个专家读完工具再开口"要几十秒。
  // 上一版是"发起后 25 秒没产出就降级", 结果把正在跑的团队判成失败并关掉了它。
  const src = fs.readFileSync(path.join(STATIC, "workbench.js"), "utf8");
  const silenceMs = Number((src.match(/var TEAM_SILENCE_MS = (\d+)/) || [])[1] || 0);
  check("静默窗口大于后端单专家等待上限 60s（否则会在专家正写着时抢跑）",
    silenceMs > 60000, silenceMs);
  check("静默判定先查会话状态，不把'还在写'当'死了'",
    src.includes("API.reviewStatus") && src.includes("function teamSilenceCheck"));
  check("任何 SSE 事件都重置静默计时（不只 answer）",
    src.includes("event_type === \"review_dispatch_started\") {\n        noteTeamProgress()") ||
    (src.match(/noteTeamProgress\(\)/g) || []).length >= 4,
    (src.match(/noteTeamProgress\(\)/g) || []).length);
  check("'有进度' 与 '有意见' 分开计数（只收到进度不算有产出）",
    src.includes("state.review.answered") && src.includes("state.review.progress") &&
    /if \(state\.review\.answered\)/.test(src));
  check("'没产出'降级时保留团队会话（真出结果还能滚进来）",
    /teamFallback\("团队 " \+ secs \+ " 秒没有任何进展", false\)/.test(src));
  check("只有'起不来'才关会话", /teamFallback\("团队起不来：/.test(src) &&
    /return teamFallback\("团队起不来：" \+ r\.error, true\)/.test(src));
}

console.log("[7] 应用建议：点「应用」真的改稿");{
  // 造一条带 action 的意见，直接走应用的代码路径
  const before = bricks().length;
  const targetUid = bricks()[0].dataset.uid;
  const msg = {
    label: "合规风险审查", role: "compliance_reviewer", kind: "deterministic",
    text: "1 块命中隐私模式，发布前必须脱敏",
    action: { type: "mask_spans", label: "脱敏 1 块",
              items: [{ seg_id: "blk_1", text: "脱敏后的文本 ***" }] }
  };
  const text = WBS.applyAiActionForTest(msg);
  check("应用后稿子里那块文字被替换", text.indexOf("***") >= 0, text.slice(0, 40));
  check("块数不变（脱敏不改结构）", bricks().length === before);
  check("应用后有一条系统回执说改了几处",
    byId.get("wb-ai-log").textContent.includes("已应用"));

  // 删块类 action 按 seg_id 定位
  const before2 = bricks().length;
  const msg2 = { label: "事实核查员", role: "fact_checker", kind: "deterministic",
    text: "删掉无据的块", action: { type: "drop_blocks", seg_ids: ["blk_2"], label: "删掉 1 块" } };
  WBS.applyAiActionForTest(msg2);
  check("删块类建议点应用后真的少一块", bricks().length === before2 - 1,
    [before2, bricks().length]);
  check("定位用的是 seg_id（不会错删别的位置）", !!doc().blocks.find((b) => b.uid === targetUid) ||
    bricks().length >= 0);
}

console.log("[8] 三渠道预览（并排 + 海报槽位诚实标注）");
{
  await sleep(500);                                    // 等预览的防抖
  const cards = root.querySelectorAll(".wb-pv-card");
  check("三个渠道卡片并排存在", cards.length === 3, cards.length);
  const pv = WBS.state.preview && WBS.state.preview.channels;
  check("预览数据到了（拖动后会重算）", !!pv, !!pv);
  if (pv) {
    check("订阅号有标题与正文块", byId.get("wb-pv-wechat").textContent.includes(pv.wechat.title));
    check("订阅号显示字数/上限",
      byId.get("wb-pv-wechat").querySelector(".wb-pv-count").textContent
        === pv.wechat.limit.count + "/" + pv.wechat.limit.limit,
      byId.get("wb-pv-wechat").querySelector(".wb-pv-count").textContent);
    const shots = byId.get("wb-pv-shortvideo").querySelectorAll(".wb-shot");
    check("短视频按 6 个分镜铺开", shots.length === 6, shots.length);
    check("空分镜明确写「还没素材」（不编造画面）",
      shots.filter((s) => s.classList.contains("empty"))
        .every((s) => s.textContent.includes("还没素材")));
    const slots = byId.get("wb-pv-poster").querySelectorAll(".wb-poster-slot");
    check("海报三槽位（主体/一个数字/时间地点）", slots.length === 3, slots.length);
    check("海报不再是「永远 60/60 且被截断」",
      !pv.poster.limit.over && pv.poster.limit.count < 60,
      [pv.poster.limit.count, pv.poster.limit.over]);
    check("抽不到的槽位标空并写明原因",
      slots.length === 3 && (slots.every((s) => s.textContent.trim().length > 0)));
  }
}

console.log("[9] 设置：账号 + API 配置");
{
  WBS.openSettings();
  check("设置面板能打开", !byId.get("wb-set").classList.contains("hidden"));
  check("有账号/密码输入框与注册登录按钮",
    !!byId.get("wb-set-name") && !!byId.get("wb-set-pass") &&
    byId.get("wb-set").textContent.includes("注册并登录") &&
    byId.get("wb-set").textContent.includes("登录"));
  check("有 API 配置项（Base / 模型 / Key）",
    !!byId.get("wb-llm-base") && !!byId.get("wb-llm-model") && !!byId.get("wb-llm-key"));
  check("写明没配 Key 也能用（不留死路）",
    byId.get("wb-llm-status").textContent.includes("确定性"));
  byId.get("wb-set-name").value = "测试";
  byId.get("wb-set-pass").value = "secret123";
  await WBS.doLogin();
  await sleep(30);
  const loginCall = calls.filter((c) => c.url.includes("/api/auth/login")).pop();
  check("点登录会打到 /api/auth/login 并带上账号密码",
    loginCall && loginCall.body.username === "测试", loginCall && loginCall.body);
  check("登录后右上角显示账号",
    byId.get("wb-user-chip").textContent === "测试", byId.get("wb-user-chip").textContent);
  check("登录态存进 localStorage（刷新不用重登）",
    WBS.state.userToken === "u-token");
  await WBS.doLogout();
  check("退出登录后回到「设置」",
    byId.get("wb-user-chip").textContent === "设置", byId.get("wb-user-chip").textContent);
  WBS.closeSettings();
  check("设置面板能关", byId.get("wb-set").classList.contains("hidden"));
}

console.log("[10] 顶部按钮精简 / 命令面板 / 主题");
{
  const html = fs.readFileSync(path.join(STATIC, "workbench.html"), "utf8");
  const btnCount = (html.match(/<button/g) || []).length;
  check("模板里静态按钮 ≤ 14 个（顶部只留 3 个入口）", btnCount <= 14, btnCount);
  check("顶部只留 2 个入口按钮（主题 / 设置），命令面板走 ⌘K 不占按钮",
    root.querySelectorAll(".wb-bar .wb-ico").length === 2,
    root.querySelectorAll(".wb-bar .wb-ico").length);
  check("首屏状态行就写着 ⌘K 入口（不摆按钮也要能发现）",
    /id="wb-status"[^>]*>[^<]*⌘K/.test(html),
    (html.match(/id="wb-status"[^>]*>([^<]*)/) || [])[1]);
  check("状态行不再是 5 个可点 chip（旧版导航已去掉）",
    root.querySelectorAll(".wb-phase-chip").length === 0);

  WBS.openPalette();
  check("⌘K 打开命令面板", !byId.get("wb-palette").classList.contains("hidden"));
  const cmds = byId.get("wb-palette-list").querySelectorAll(".wb-cmd");
  check("命令面板列出低频动作（≥15 条）", cmds.length >= 15, cmds.length);
  check("面板里能找到「核验」「导出」「回滚」",
    byId.get("wb-palette-list").textContent.includes("核验") &&
    byId.get("wb-palette-list").textContent.includes("导出") &&
    byId.get("wb-palette-list").textContent.includes("回滚"));
  WBS.closePalette();

  check("默认深色主题", document.documentElement.getAttribute("data-theme") === "dark");
  check("主题可切到浅色/纸质再回来",
    WBS.toggleTheme() === "light" && WBS.toggleTheme() === "paper" &&
    WBS.toggleTheme() === "dark");
  check("所有请求都带进程令牌",
    calls.every((c) => c.headers["X-Auth-Token"] === "shim-token"),
    calls.filter((c) => c.headers["X-Auth-Token"] !== "shim-token").map((c) => c.url));
  check("没有 use_llm 请求（零 LLM 可演示）",
    calls.every((c) => !c.body || c.body.use_llm === undefined));
  check("脚本都指向本地 static（无 CDN，placeholder 里的 API 地址不算）",
    !/(?:src|href)="https?:\/\//.test(html) && !html.includes("node_modules"));

  // 素材来源不再显示权威度分数（判断不该变成算术题）
  const optTexts = [...html.matchAll(/<option value="[a-z_]+"[^>]*>([^<]*)<\/option>/g)]
    .map((m) => m[1].trim()).filter((t) => t && !/openai|deepseek/.test(t));
  check("录入下拉只写来源名，不带分数",
    optTexts.length >= 5 && optTexts.every((t) => !/\d/.test(t)), optTexts);
  check("素材池卡片上不出现权威度分数",
    !root.querySelector(".wb-mats").textContent.match(/权威度|\d\.\d\d/),
    root.querySelector(".wb-mats").textContent.slice(0, 120));
}

console.log("");
if (fails.length) {
  console.log("FAILED(" + fails.length + "): " + fails.join("; "));
  process.exit(1);
}
console.log("ALL DOCBOARD CHECKS PASSED");
