# coding: utf-8
"""_test_content_foundation.py — 内容域地基验证(design/11 §4 + §9 T1.2/T2.3)。

覆盖:
  A. 素材类型 / 来源权威度 / 缺口类型常量
  B. 量化抽取(内容域语序: 后缀单位 + 人数型)
  C. 素材类型推断 guess_material_type
  D. EventRecord 内容域字段读写与向后兼容
  E. empty_state 的 cites 子图 + 老日志/老快照迁移容错
  F. 全链路零 LLM 断言(本测试不导入任何 LLM 组件)
"""
import json
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from graphstore import (  # noqa: E402
    FileGraphStore, EventRecord, WeakItem, Period,
    norm_text, extract_metrics, extract_techs,
    authority_of, authority_band, guess_material_type, empty_state, iso_now,
    MATERIAL_TYPES, GAP_TYPES, SOURCE_AUTHORITY, LOW_AUTHORITY,
    ACTIVITY, NOTICE, PERSON, ACHIEVEMENT, ORG, BACKGROUND,
    NO_SOURCE, CONFLICT, SENSITIVE, ISOLATED, STALE,
)

BASE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "data", "_test_content_foundation_tmp")

FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


# ---------- A. 常量 ----------
def test_constants():
    print("[A] 常量")
    check("素材类型 6 类", len(MATERIAL_TYPES) == 6, MATERIAL_TYPES)
    check("缺口类型 5 类", len(GAP_TYPES) == 5, GAP_TYPES)
    check("官方文档权威度最高", authority_of("official_doc") == 1.00)
    check("未知来源不猜高", authority_of("") == 0.30 and authority_of("wechat") == 0.30)
    check("权威度分档 official", authority_band(1.0) == "official")
    check("权威度分档 hearsay", authority_band(0.3) == "hearsay")
    check("孤证阈值可比较", authority_of("member") <= LOW_AUTHORITY < authority_of("on_site"))


# ---------- B. 量化抽取 ----------
def test_metrics():
    print("[B] 量化抽取")
    m = extract_metrics("活动现场到场约200人")
    check("后缀单位: 到场约200人", any(x.key == "attendees" and x.value == 200 for x in m), m)

    m = extract_metrics("签到表显示参加人数 183 人")
    check("空格+量词: 183 人", any(x.key == "attendees" and x.value == 183 for x in m), m)

    m = extract_metrics("共举办5场讲座")
    check("量词 场", any(x.key == "sessions" and x.value == 5 for x in m), m)

    m = extract_metrics("推文累计阅读量 1200")
    check("无单位数字", any(x.key == "views" and x.value == 1200 for x in m), m)

    m = extract_metrics("比起往届效率提升30%")
    check("历史指标词仍可抽(准确率类)", isinstance(m, list))

    m = extract_metrics("今年报名队伍共 12 支")
    check("队伍 12 支", any(x.key == "teams" and x.value == 12 for x in m), m)

    # 同一指标键只取首个, 不重复
    m = extract_metrics("到场200人，另有志愿者100人到场")
    check("同键只取首个", len([x for x in m if x.key == "attendees"]) == 1, m)


# ---------- C. 素材类型推断 ----------
def test_material_type():
    print("[C] 素材类型推断")
    cases = [
        ("我社荣获校级十佳社团称号", ACHIEVEMENT),
        ("关于活动时间调整的通知，场地变更为报告厅", NOTICE),
        ("社长张同学表示这次活动收获很大", PERSON),
        ("本社团隶属于计算机学院团委", ORG),
        ("11月20日举办编程马拉松比赛，现场有讲座与沙龙", ACTIVITY),
        ("社团章程沿革与往届情况说明", BACKGROUND),
    ]
    for text, want in cases:
        got = guess_material_type(text, "", [], None)
        check("推断 %s" % want, got == want, "text=%s got=%s" % (text[:14], got))


# ---------- D. EventRecord 内容域字段 ----------
def test_event_record():
    print("[D] EventRecord 字段")
    rec = EventRecord(type=ACTIVITY, subject="编程马拉松比赛",
                      content="11月20日举办编程马拉松比赛，到场约200人",
                      source="official_doc", authority=1.00, verified=False, sensitive=False)
    d = rec.to_dict()
    check("to_dict 含 authority", d.get("authority") == 1.00, d.get("authority"))
    check("to_dict 含 verified/sensitive",
          d.get("verified") is False and d.get("sensitive") is False)
    back = EventRecord.from_dict(d)
    check("roundtrip authority", back.authority == 1.00)
    check("roundtrip verified", back.verified is False)

    # 向后兼容: 老记录没有 authority 字段 → 由 source 推
    old = {"type": "activity", "subject": "x", "content": "y", "source": "organizer"}
    r2 = EventRecord.from_dict(old)
    check("老记录按 source 补权威度", r2.authority == SOURCE_AUTHORITY["organizer"], r2.authority)
    check("老记录 verified 默认 False", r2.verified is False)

    w = WeakItem(event_id="evt_000001", event_content="到场约200人",
                 weakness_type=NO_SOURCE, priority=0.9, reason="无据",
                 claim="到场约200人", source_eid="evt_000001")
    wd = w.to_dict()
    check("WeakItem 含 claim/source_eid",
          wd.get("claim") == "到场约200人" and wd.get("source_eid") == "evt_000001")
    check("WeakItem roundtrip", WeakItem.from_dict(wd).claim == "到场约200人")


# ---------- E. cites 子图与老数据迁移 ----------
def test_cites_and_migration():
    print("[E] cites 子图 / 老数据容错")
    st = empty_state()
    check("empty_state 含 cites", "cites" in st["edges"], list(st["edges"]))

    root = os.path.join(BASE, "store_new")
    sid = "club_a"
    g = FileGraphStore(root, sid, snapshot_every=20)
    g.open()
    g.commit("ADD_EVENT", {"record": {
        "type": ACTIVITY, "subject": "编程马拉松比赛",
        "content": "11月20日举办编程马拉松比赛，到场约200人",
        "source": "official_doc", "authority": 1.00, "metrics": [], "claims": []}},
        session_id="s1")
    g.commit("ADD_EVENT", {"record": {
        "type": ACTIVITY, "subject": "往届编程马拉松",
        "content": "2024年11月举办上届编程马拉松比赛", "source": "official_doc",
        "authority": 1.00, "metrics": [], "claims": []}}, session_id="s1")
    g.commit("ADD_EDGE", {"graph": "cites", "src": "seg_1", "tgt": "evt_000001",
                          "weight": 1.0}, session_id="s1")
    cites = g.latest()["edges"]["cites"]
    check("cites 是有向边(键 seg>eid, 方向即溯源)", "seg_1>evt_000001" in cites, list(cites))
    check("cites 不应出现无向键", "evt_000001|seg_1" not in cites, list(cites))
    check("temporal 往届边由规则生成", len(g.latest()["edges"]["temporal"]) >= 0)

    # 重开(快照+重放) → cites 边存活
    g2 = FileGraphStore(root, sid, snapshot_every=20)
    g2.open()
    check("重开后 cites 边存活", "seg_1>evt_000001" in g2.latest()["edges"]["cites"])
    check("事件数 2", len(g2.latest()["events"]) == 2)
    check("素材权威度随事件存活",
          all(e.get("authority") == 1.00 for e in g2.latest()["events"].values()))

    # 回滚到 seq=2 → cites 边随日志截断消失
    g2.rollback(2, session_id="s2", reason="test")
    check("回滚后 cites 边消失", "seg_1>evt_000001" not in g2.latest()["edges"]["cites"])

    # 老数据迁移: 手写一份没有 cites 的 state 快照 + 一条 log, 打开必须不报错
    root_old = os.path.join(BASE, "store_old")
    old_dir = os.path.join(root_old, "club_b")
    os.makedirs(os.path.join(old_dir, "snapshots"), exist_ok=True)
    legacy_state = {"events": {}, "weak": [],
                    "edges": {"entity": {}, "temporal": {}, "causal": {}}}
    # 注意: 文件名不能叫 seq_%06d.json —— 那会撞上快照正则被当成真快照
    with open(os.path.join(old_dir, "snapshots", "legacy_000001.json"), "w",
              encoding="utf-8") as f:
        json.dump({"seq": 1, "head": 1, "reason": "legacy", "state": legacy_state}, f)
    with open(os.path.join(old_dir, "head.json"), "w", encoding="utf-8") as f:
        json.dump({"head_seq": 2, "updated_at": iso_now()}, f)
    op = {"seq": 2, "ts": iso_now(), "session_id": "s1", "op": "ADD_EVENT",
          "payload": {"record": {"type": ACTIVITY, "subject": "老素材",
                                 "content": "来自旧版本的一行", "source": "member",
                                 "metrics": [], "claims": []}}}
    with open(os.path.join(old_dir, "log.jsonl"), "w", encoding="utf-8") as f:
        f.write(json.dumps({"seq": 1, "ts": iso_now(), "session_id": "s1",
                            "op": "ADD_EVENT",
                            "payload": {"record": {"type": NOTICE, "subject": "更老的素材",
                                                   "content": "旧版第一行", "source": "hearsay",
                                                   "metrics": [], "claims": []}}},
                           ensure_ascii=False) + "\n")
        f.write(json.dumps(op, ensure_ascii=False) + "\n")

    g3 = FileGraphStore(root_old, "club_b", snapshot_every=20)
    g3.open()
    check("老数据可打开", g3.head_seq == 2, g3.head_seq)
    check("老数据补齐 cites 键", "cites" in g3.state["edges"], list(g3.state["edges"]))
    check("老数据事件已重放", len(g3.latest()["events"]) == 2, len(g3.latest()["events"]))
    old_authority = sorted(e.get("authority") for e in g3.latest()["events"].values())
    check("老素材按 source 补权威度", old_authority == [0.30, 0.50], old_authority)

    # 缺口带断言原句: claim/source_eid 必须落盘(待核实清单靠它指回原文)
    g3.commit("ADD_WEAK", {"event_id": "evt_000002", "weakness_type": NO_SOURCE,
                           "priority": 0.9, "reason": "素材库找不到支撑",
                           "claim": "反响热烈", "source_eid": "evt_000002"}, session_id="s3")
    w0 = g3.latest()["weak"][0]
    check("缺口落 claim", w0.get("claim") == "反响热烈", w0)
    check("缺口落 source_eid", w0.get("source_eid") == "evt_000002", w0)
    g4 = FileGraphStore(root_old, "club_b", snapshot_every=20)
    g4.open()
    check("缺口 claim 重开后存活", g4.latest()["weak"][0].get("claim") == "反响热烈")

    g3.commit("ADD_EDGE", {"graph": "cites", "src": "seg_9", "tgt": "evt_000002"},
              session_id="s3")
    check("老库也能写 cites", "seg_9>evt_000002" in g3.latest()["edges"]["cites"],
          list(g3.latest()["edges"]["cites"]))


def main():
    try:
        test_constants()
        test_metrics()
        test_material_type()
        test_event_record()
        test_cites_and_migration()
    finally:
        shutil.rmtree(BASE, ignore_errors=True)
    if FAILS:
        print("\n内容域地基测试 FAILED: %d 项" % len(FAILS))
        raise SystemExit(1)
    print("\n内容域地基测试 PASSED")


if __name__ == "__main__":
    main()
