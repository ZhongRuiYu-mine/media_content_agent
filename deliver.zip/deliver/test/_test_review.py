# coding: utf-8
"""_test_review.py — headless 验证复盘会话 MVP + R1 收尾（resume/延续记忆）。

流程：新建→回复→继续对话→关闭→(模拟重启)resume→继续对话→审计。
验证：常驻团队(LLM 自然暂停)、history 落盘回放、resume 重连/COLD_RECOVER、llm_gate 审计。

隔离：REVIEWS_HOME / LLM_GATE_LOG 指向临时目录，不碰项目已有数据，结束自清理。

运行：D:\\jiuwen\\Scripts\\python _test_review.py
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import uuid

_PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PROJ)  # 项目根
_TMP = os.path.join(_PROJ, "test_review_" + uuid.uuid4().hex[:8])
os.makedirs(_TMP, exist_ok=True)
os.environ["REVIEWS_HOME"] = os.path.join(_TMP, "reviews")
os.environ["LLM_GATE_LOG"] = os.path.join(_TMP, "llm_gate.jsonl")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass

import components.review_runtime as rr_mod  # noqa: E402
from components.review_runtime import get_review_runtime  # noqa: E402
from components import llm_gate  # noqa: E402


async def _consume_until_idle(rt, review_id: str, timeout: float = 150) -> tuple[str, bool, int]:
    """从流里读到 team.idle / done / error，返回 (answer, saw_idle, history_count)。"""
    ans = ""
    idle = False
    hist = 0

    async def consume():
        nonlocal ans, idle, hist
        async for raw in rt.iter_stream(review_id):
            c = json.loads(raw)
            t = c.get("type")
            p = c.get("payload") or {}
            if t == "history":
                hist = len(p.get("messages") or [])
            elif t == "answer":
                ans = p.get("output") or ""
            elif t == "message" and p.get("event_type") == "team.idle":
                idle = True
                return
            elif t in ("done", "error"):
                return

    await asyncio.wait_for(consume(), timeout)
    return ans, idle, hist


async def _consume_history_only(rt, review_id: str, timeout: float = 15) -> int:
    """只读首个 history 事件，返回消息条数（不阻塞等 live chunk）。"""
    async def consume():
        async for raw in rt.iter_stream(review_id):
            c = json.loads(raw)
            if c.get("type") == "history":
                return len((c.get("payload") or {}).get("messages") or [])
            return 0

    return await asyncio.wait_for(consume(), timeout)


async def main() -> int:
    rt = get_review_runtime()
    student = "default"

    print("=" * 70)
    s = await rt.create(student, "root")
    rid = s["review_id"]
    print(f"[create] {rid} node={s['node_id']}")

    ans1, idle1, h1 = await _consume_until_idle(rt, rid)
    print(f"[第一轮] idle={idle1} history={h1} ans_len={len(ans1)}")

    await rt.interact(rid, "请给我一个具体改进建议")
    ans2, idle2, h2 = await _consume_until_idle(rt, rid)
    print(f"[第二轮] idle={idle2} history={h2} ans_len={len(ans2)}")

    # 进程内 resume（重连）：验证 history 回放
    st = await rt.resume(rid)
    print(f"[进程内 resume] status={st['status']} history_count={st['history_count']}")
    h_replay = await _consume_history_only(rt, rid)
    print(f"[重连回放] history={h_replay}")

    await rt.close(rid)
    print(f"[close] status={rt.status(rid)['status']}")

    # 模拟重启：重置单例（新进程内状态），保留磁盘 checkpoint + sqlite 团队库
    rr_mod._RUNTIME = None
    rt2 = get_review_runtime()
    st2 = await rt2.resume(rid)
    print(f"[重启后 resume] status={st2.get('status')} history_count={st2.get('history_count')} "
          f"error={st2.get('error')}")
    ansA, idleA, hA = await _consume_until_idle(rt2, rid)
    print(f"[恢复确认] idle={idleA} ans_len={len(ansA)} history={hA}")
    r3 = await rt2.interact(rid, "我们继续复盘，还记得上一轮说了什么吗？")
    print(f"[重启后 interact] ok={r3.get('ok')} reason={r3.get('reason')}")
    ans3, idle3, h3 = await _consume_until_idle(rt2, rid)
    print(f"[重启后继续] idle={idle3} history={h3} ans_len={len(ans3)}")
    print(f"  leader: {ans3[:120]}...")

    print("-" * 70)
    c = llm_gate.counters()
    print(f"[LLM 审计] default={c.get('default')} authorized={c.get('authorized')} "
          f"unregistered={c.get('unregistered')}")
    for pid, p in (c.get("by_point") or {}).items():
        print(f"  点 {pid}: ok={p.get('ok')} error={p.get('error')}")
    # openjiuwen 常驻团队的后台线程使 asyncio.run 无法正常返回, 流程完成后直接强制退出
    shutil.rmtree(_TMP, ignore_errors=True)
    os._exit(0)


if __name__ == "__main__":
    code = 1
    try:
        code = asyncio.run(main())
    except KeyboardInterrupt:
        code = 130
    except Exception:  # noqa: BLE001
        import traceback

        traceback.print_exc()
        code = 1
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
    print(f"\n[退出码] {code}")
    os._exit(code)  # 常驻团队的后台线程不随 asyncio.run 退出, 直接强制结束
