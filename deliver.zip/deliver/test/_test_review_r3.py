# coding: utf-8
"""_test_review_r3.py — headless 验证 R3：HOTS 指挥群(swarmflow 重评分/重出题)。

流程：新建复盘 → leader 开场 → hots re_score(并行 worker) → 结果 →
hots re_question(带事件库背景) → 结果 + 入库状态 → LLM 审计(P11/P12/P13)。

隔离：REVIEWS_HOME / LLM_GATE_LOG / USER_PROFILE_DIR / RESUME_DIR 全指临时目录。

运行：D:\\jiuwen\\Scripts\\python _test_review_r3.py
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import sys
import uuid

_PROJ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PROJ)  # 项目根
_TMP = os.path.join(_PROJ, "test_review_r3_" + uuid.uuid4().hex[:8])
os.makedirs(_TMP, exist_ok=True)
os.environ["REVIEWS_HOME"] = os.path.join(_TMP, "reviews")
os.environ["LLM_GATE_LOG"] = os.path.join(_TMP, "llm_gate.jsonl")
os.environ["USER_PROFILE_DIR"] = os.path.join(_TMP, "profiles")
os.environ["RESUME_DIR"] = os.path.join(_TMP, "resumes")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass

from components.review_runtime import get_review_runtime  # noqa: E402
from components import llm_gate  # noqa: E402


async def _consume_until(rt, review_id, want: str, timeout: float = 240):
    """读到指定类型的 chunk(hots_result / team.idle)，返回 payload 或 None。"""
    found = {}

    async def consume():
        async for raw in rt.iter_stream(review_id):
            c = json.loads(raw)
            t = c.get("type")
            p = c.get("payload") or {}
            if t == want:
                found["payload"] = p
                return
            if want == "team.idle" and t == "message" and p.get("event_type") == "team.idle":
                found["payload"] = p
                return
            if t == "error":
                found["payload"] = {"error": p.get("error")}
                return

    await asyncio.wait_for(consume(), timeout)
    return found.get("payload")


async def main() -> int:
    student = "default"
    print("=" * 70)
    rt = get_review_runtime()
    s = await rt.create(student, "root")
    rid = s["review_id"]
    idle = await _consume_until(rt, rid, "team.idle")
    print(f"[leader 开场] idle_payload={'有' if idle else '无'}")

    ans_payload = {
        "question": "你做过最难的性能优化是什么？",
        "answer": "我做过一次数据库查询优化，把一次慢查询拆成了两次，感觉快了不少，"
                  "但没有记录具体提升了多少。",
    }

    r1 = await rt.hots(rid, "re_score", dict(ans_payload))
    print(f"[hots re_score 启动] {r1}")
    res1 = await _consume_until(rt, rid, "hots_result")
    print(f"[hots re_score 结果] ok={res1.get('ok') if res1 else '超时'} "
          f"err={res1.get('error') if res1 else ''}")
    if res1 and res1.get("ok"):
        print("  " + json.dumps(res1.get("result"), ensure_ascii=False)[:400])

    r2 = await rt.hots(rid, "re_question", dict(ans_payload))
    print(f"[hots re_question 启动] {r2}")
    res2 = await _consume_until(rt, rid, "hots_result")
    print(f"[hots re_question 结果] ok={res2.get('ok') if res2 else '超时'}")
    if res2 and res2.get("ok"):
        print("  " + json.dumps(res2.get("result"), ensure_ascii=False)[:400])

    await rt.close(rid)

    print("-" * 70)
    c = llm_gate.counters()
    print(f"[LLM 审计] default={c.get('default')} unregistered={c.get('unregistered')}")
    for pid, p in sorted((c.get("by_point") or {}).items()):
        print(f"  点 {pid}: ok={p.get('ok')} error={p.get('error')}")
    # openjiuwen 常驻团队的后台线程使 asyncio.run 无法正常返回, 流程完成后直接强制退出
    shutil.rmtree(_TMP, ignore_errors=True)
    os._exit(0)


if __name__ == "__main__":
    code = 1
    try:
        code = asyncio.run(main())
    except KeyboardInterrupt:
        code = 130
    except Exception:  # noqa: BLE001
        import traceback

        traceback.print_exc()
        code = 1
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
    print(f"\n[退出码] {code}")
    os._exit(code)  # 常驻团队的后台线程不随 asyncio.run 退出, 直接强制结束
