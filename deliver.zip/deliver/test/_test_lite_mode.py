# coding: utf-8
"""_test_lite_mode.py — 验证"只装 starlette 也能跑"这条交付承诺。

做法：在**同一个进程**里先装一个 import 拦截器，把 openjiuwen / swarmflow /
sentence_transformers / sklearn / numpy / pymongo 全部标记为"没装"，再跑：
  ① import server + 起 TestClient，打核心接口（素材/缺口/成稿/核验/预览/六角色/账号）；
  ② 断言 team 路线给出的是**一句人话的降级原因**，不是 ImportError 栈；
  ③ 断言 capabilities 里 core=ok、llm=不可用。

这不是"假设"，是真的把依赖拦掉再跑一遍 —— 换台干净机器会不会崩，就看这一条。

用法: D:\\jiuwen\\Scripts\\python.exe test\\_test_lite_mode.py
"""
import os
import sys
import uuid

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _HERE)

# ---- 数据目录全部指到临时目录（必须在 import server 之前）----
import shutil
import tempfile

_TMP = os.path.join(_HERE, "data", "_test_lite_tmp")
shutil.rmtree(_TMP, ignore_errors=True)
os.makedirs(_TMP, exist_ok=True)
os.environ.update({
    "EMBEDDING_OFF": "1",
    "LLM_GATE_MODE": "auto_deny",
    "TOPIC_STORE_BACKEND": "file",
    "AUTH_TOKEN": "lite-token",
    "STORAGE_BASE_DIR": os.path.join(_TMP, "graphs"),
    "CONTENT_VERSIONS_DIR": os.path.join(_TMP, "versions"),
    "TOPIC_BANK_DIR": os.path.join(_TMP, "topics"),
    "REPORT_DIR": os.path.join(_TMP, "reports"),
    "RESOLUTION_DIR": os.path.join(_TMP, "resolutions"),
    "USERS_FILE": os.path.join(_TMP, "users.json"),
    "LLM_GATE_LOG": os.path.join(_TMP, "llm_gate.jsonl"),
})

# ---- 关键一步：把"重依赖"全部拦掉，模拟一台干净机器 ----
BLOCKED = ("openjiuwen", "swarmflow", "sentence_transformers", "sklearn",
           "numpy", "pymongo", "torch", "transformers")
_BLOCKED_TOP = set(BLOCKED)
_orig_import = __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__


def _guarded_import(name, *args, **kwargs):
    if name.split(".")[0] in _BLOCKED_TOP:
        raise ImportError(f"[lite-test] 这台机器没装 {name.split('.')[0]}")
    return _orig_import(name, *args, **kwargs)


if isinstance(__builtins__, dict):
    __builtins__["__import__"] = _guarded_import
else:
    __builtins__.__import__ = _guarded_import
for _m in list(sys.modules):
    if _m.split(".")[0] in _BLOCKED_TOP:
        del sys.modules[_m]

FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def main():
    print("[1] 拦掉重依赖后，核心模块还能 import 吗")
    try:
        import server  # noqa: F401
        ok_server = True
    except Exception as e:  # noqa: BLE001
        ok_server = False
        print("      server 起不来:", type(e).__name__, e)
    check("只有 starlette/uvicorn 时 server 能 import", ok_server)
    if not ok_server:
        return 1
    import config
    from components import content_tools, _llm
    check("config 标记 LLM 运行时不可用", config.LLM_RUNTIME_AVAILABLE is False)
    check("_llm 明确报告不可用", _llm.llm_runtime_available() is False)
    check("content_tools 报告团队工具不可用", content_tools.TEAM_TOOLS_AVAILABLE is False)
    check("没 Key 时 build_llm_config 返回 None(不抛异常)",
          _llm.build_llm_config(config.DEFAULT_CONFIG) is None)

    print("[2] 核心链路走一遍（HTTP，零重依赖）")
    from starlette.testclient import TestClient
    C = TestClient(server.app)
    H = {"X-Auth-Token": "lite-token"}
    club = "lite_" + uuid.uuid4().hex[:6]
    check("/workbench 200", C.get("/workbench").status_code == 200)
    seed = C.post("/api/content/seed_demo", json={"club_id": club}, headers=H).json()
    check("灌演示语料", seed.get("count") == 11, seed.get("count"))
    st = C.get("/api/content/state", params={"club_id": club}, headers=H).json()
    check("素材库可读", len(st.get("materials") or []) == 11, len(st.get("materials") or []))
    gaps = C.get("/api/content/checklist", params={"club_id": club}, headers=H).json()
    check("待核实清单可读", len(gaps.get("check_list") or []) >= 5,
          len(gaps.get("check_list") or []))
    d = C.post("/api/content/draft", json={"club_id": club, "max_segments": 6}, headers=H).json()
    check("成稿可用", len((d.get("draft") or {}).get("segments") or []) == 6,
          len((d.get("draft") or {}).get("segments") or []))
    v = C.post("/api/content/verify", json={"club_id": club}, headers=H).json()
    check("核验可用", "verify" in v and "block" in v)
    pf = C.post("/api/content/platforms", json={"club_id": club, "force": True},
                headers=H).json()
    check("多平台适配可用", set(pf.get("platforms") or {}) ==
          {"wechat", "shortvideo", "poster"}, list(pf.get("platforms") or {}))

    segs = [{"seg_id": "blk_1", "kind": "block",
             "text": "计算机学院于11月20日在第三报告厅举办编程马拉松比赛",
             "source_refs": ["evt_000001"]},
            {"seg_id": "blk_2", "kind": "block",
             "text": "请联系负责人张同学，电话13812345678", "source_refs": []}]
    pv = C.post("/api/content/preview", json={"segments": segs}, headers=H).json()
    check("三渠道预览可用", set(pv.get("channels") or {}) ==
          {"wechat", "shortvideo", "poster"}, list(pv.get("channels") or {}))
    asst = C.post("/api/content/assist",
                  json={"club_id": club, "segments": segs,
                        "roles": ["fact_checker", "compliance_reviewer"]},
                  headers=H).json()
    check("六角色确定性辅助可用", len(asst.get("messages") or []) == 2,
          len(asst.get("messages") or []))
    check("辅助结论标注为确定性（不假装是大模型）",
          asst.get("llm_used") is False and "确定性" in (asst.get("note") or ""))
    act = [m for m in (asst.get("messages") or []) if m.get("action")]
    check("仍能给出可一键应用的改动（脱敏）", bool(act), [m.get("action_label") for m in act])

    print("[3] 团队路线：给一句人话的降级原因，不是 ImportError 栈")
    rv = C.post("/api/content/review", json={"club_id": club,
                                             "roles": ["fact_checker"]}, headers=H)
    body = rv.json() if rv.status_code == 200 else {}
    check("团队路线返回可读错误(不 500)", rv.status_code in (200, 400), rv.status_code)
    check("错误里说清'没装 LLM 运行时'",
          "openjiuwen" in str(body.get("error") or ""), body.get("error"))

    print("[4] 能力清单自检")
    cfg = C.get("/api/config", headers=H).json()
    caps = cfg.get("capabilities") or {}
    check("core=可用", (caps.get("core") or {}).get("ok") is True)
    check("llm=不可用(本机确实没装)", (caps.get("llm") or {}).get("ok") is False, caps.get("llm"))
    check("每项都写清需要什么", all((v or {}).get("needs") for v in caps.values()), caps)

    print("[5] 账号与设置（同样不依赖重库）")
    reg = C.post("/api/auth/register",
                 json={"username": "lite用户", "password": "secret123"}, headers=H).json()
    check("注册可用", reg.get("ok") is True, reg)
    hdr = {**H, "X-User-Token": reg.get("token") or ""}
    llm = C.post("/api/user/llm", json={"api_key": "sk-lite"}, headers=hdr).json()
    check("存 API Key 可用（只是存着，本机调不动）", llm.get("configured") is True, llm)

    print("")
    if FAILS:
        print("轻装模式测试 FAILED(%d): %s" % (len(FAILS), "; ".join(FAILS)))
        return 1
    print("轻装模式测试 PASSED（只 starlette 也能跑通核心链路）")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
