# coding: utf-8
"""_test_stage2_publish.py — 阶段 2(发布相)验证: design/11 §9 T2.1–T2.5 + 验收 A2/A5。

覆盖:
  T2.1 topic_gap: 三维度扫描(素材多但无稿 / 有稿但素材薄 / 往届有今年无) + 排序
  T2.2 content_engine: 决策链 7 级降级 + 段状态机 + 收敛
  T2.3 content_store/content_versions: 选题轮询去重 + 稿件版本按 seq 回看
  T2.4 render/platform_spec: 双轨渲染 + 平台字数上限
  验收 A2: 素材图回滚 → 稿件与平台版本同步回退
  验收 A5: 轨二润色与轨一的**断言级 diff**(数字/专名集合必须完全一致)

零 LLM: 本测试同样把闸门设为 auto_deny(轨二用"人工构造的润色文本"验证 diff 逻辑,
真实 LLM 调用不在离线测试范围内)。
"""
import os
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["EMBEDDING_OFF"] = "1"
os.environ["LLM_GATE_MODE"] = "auto_deny"
os.environ["TOPIC_STORE_BACKEND"] = "file"          # 离线: 选题库走 File 兜底
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TMP = os.path.join(_HERE, "data", "_test_stage2_tmp")
os.environ["STORAGE_BASE_DIR"] = os.path.join(_TMP, "graphs")
os.environ["CONTENT_VERSIONS_DIR"] = os.path.join(_TMP, "versions")
os.environ["TOPIC_BANK_DIR"] = os.path.join(_TMP, "topics")
os.environ["REPORT_DIR"] = os.path.join(_TMP, "reports")
os.environ["RESOLUTION_DIR"] = os.path.join(_TMP, "resolutions")

from content import demo_corpus as corpus                      # noqa: E402
from content import platform_spec as spec                      # noqa: E402
from content.content_engine import (                           # noqa: E402
    S_SEG_BLOCKED, S_SEG_DRAFTED, S_SEG_VERIFIED, ContentEngine, take_clause,
)
from content.content_runtime import ContentRuntime             # noqa: E402
from content.content_store import TopicStore                   # noqa: E402
from content.content_versions import (                         # noqa: E402
    draft_to_text, get_version, save_version, versions,
)
from content.render import (                                   # noqa: E402
    assertion_diff, assertion_set, export_package, render_all, render_segments,
)
from content.topic_gap import (                                # noqa: E402
    MIN_ACTIVITY_MATERIALS, MIN_CITES, rank_topics, scan_topics,
)
from graphstore.types import CONFLICT                          # noqa: E402

FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def _mats():
    from content.material_analyst import build_material_record
    out = []
    for i, m in enumerate(corpus.all_materials(), start=1):
        rec = build_material_record(m)
        rec["eid"] = f"evt_{i:06d}"
        rec["created_seq"] = i
        out.append(rec)
    return out


# ---------- T2.1 ----------
def test_topic_gap():
    print("[T2.1] topic_gap: 三维度扫描 + 排序")
    mats = _mats()
    # 没有稿件 + 素材够多 → "素材多但无稿"
    topics = scan_topics(mats, [], {}, [], {"current": "2025-11"})
    kinds = {t["kind"] for t in topics}
    check("维度1: 素材多但无稿", "no_draft" in kinds, [(t["kind"], t["subject"]) for t in topics])
    nd = [t for t in topics if t["kind"] == "no_draft"][0]
    check("维度1: 缺口数=关联素材数", nd["gap_count"] >= MIN_ACTIVITY_MATERIALS, nd)
    check("维度1: 排序分 = 缺口数×权重×权威度均值",
          abs(nd["score"] - nd["gap_count"] * nd["weight"] * nd["authority_mean"]) < 1e-6,
          nd)

    # 有稿但 cites 少 → "有稿但素材薄"
    drafts = [{"topic": "编程马拉松比赛", "seq": 20, "eids": ["evt_000004"]}]
    topics2 = scan_topics(mats, drafts, {"seg_1>evt_000004": {"src": "seg_1", "tgt": "evt_000004"}},
                          [{"weakness_type": "no_source", "claim": "本次比赛反响热烈",
                            "assertion": "反响热烈"}],
                          {"current": "2025-11"})
    check("维度2: 有稿但素材薄", any(t["kind"] == "thin_source" for t in topics2),
          [(t["kind"], t["reason"]) for t in topics2])
    thin = [t for t in topics2 if t["kind"] == "thin_source"][0]
    check("维度2: 理由写明 cites 与无据缺口", "cites" in thin["reason"], thin["reason"])

    # 有稿 → 该主题的"素材多但无稿"应当消失
    check("有稿后维度1 不再报该主题",
          not any(t["kind"] == "no_draft" and "编程马拉松" in t["subject"] for t in topics2),
          [t["subject"] for t in topics2 if t["kind"] == "no_draft"])

    # 往届有稿、今年无 → "往届有今年无"(依赖 temporal 往届边, design/11 §5.2 维度 3)
    hist_drafts = [{"topic": "上届编程马拉松比赛", "seq": 5}]
    temporal = {
        "evt_000001>evt_000004": {"src": "evt_000001", "tgt": "evt_000004", "kind": "before"},
        "evt_000001>evt_000005": {"src": "evt_000001", "tgt": "evt_000005", "kind": "before"},
    }
    topics3 = scan_topics(mats, hist_drafts, {}, [], {"current": "2025-11"}, temporal)
    check("维度3: 往届有今年无", any(t["kind"] == "no_current" for t in topics3),
          [(t["kind"], t["subject"]) for t in topics3])

    # 今年也有稿 → 维度3 不再报
    today_drafts = hist_drafts + [{"topic": "编程马拉松比赛", "seq": 9}]
    topics4 = scan_topics(mats, today_drafts, {}, [], {"current": "2025-11"}, temporal)
    check("今年有稿后维度3 消失",
          not any(t["kind"] == "no_current" for t in topics4),
          [(t["kind"], t["subject"]) for t in topics4])

    ranked = rank_topics(topics + topics3, top=2)
    check("排序取前 N", len(ranked) == 2, ranked)
    check("排序按 score 降序",
          all(ranked[i]["score"] >= ranked[i + 1]["score"] for i in range(len(ranked) - 1)),
          [r["score"] for r in ranked])


# ---------- T2.2 ----------
def test_engine():
    print("[T2.2] content_engine: 决策链 + 段状态机 + 收敛")
    mats = _mats()
    eng = ContentEngine()
    d = eng.draft(mats, [{"subject": "本届编程马拉松比赛", "score": 1.0}], None,
                  intents=["报道"], window={"current": "2025-11"})
    segs = d["segments"]
    check("六段成稿", len(segs) == 6, [s["kind"] for s in segs])
    check("段结构符合规范", [s["kind"] for s in segs] == list(spec.SEGMENTS), [s["kind"] for s in segs])
    check("每段初始状态 = drafted", all(s["status"] == S_SEG_DRAFTED for s in segs))
    # 有素材依据的段必须带来源指针; 缺口兜底段(如"部分素材含个人信息…")从设计上就
    # **不该**登记来源 —— 它引用的素材尚未被确认可用, 登记了会污染溯源链。
    sourced = [s for s in segs if not s.get("gap_only")]
    check("有依据的段都带 source_refs(溯源链)",
          all(s["source_refs"] for s in sourced), [s["seg_id"] for s in sourced])
    check("缺口兜底段不登记来源(不污染溯源链)",
          all(not s["source_refs"] for s in segs if s.get("gap_only")),
          [(s["seg_id"], s.get("source_refs")) for s in segs if s.get("gap_only")])
    check("决策链每段留下理由", all(s["reason"] for s in d["steps"]), d["steps"][:1])
    sources = {s["source_used"] for s in d["steps"]}
    check("用到了确定性降级路径(不只一级)",
          len(sources & {"type_pick", "gap_segment", "intent_draw", "template",
                         "split_segment", "topic_rotate"}) >= 2, sources)
    check("收敛判定给出上限与缺口覆盖", "by_cap" in d["converged"]
          and "gaps_covered" in d["converged"], d["converged"])
    check("成稿登记 cites 边", len(d["cite_edges"]) >= 1, d["cite_edges"][:2])

    from content.fact_verifier import verify_draft
    res = verify_draft(d, mats, {"current": "2025-11"})
    eng.apply_verification(d, res)
    check("段状态机推进(verified/blocked)",
          all(s["status"] in (S_SEG_VERIFIED, S_SEG_BLOCKED) for s in d["segments"]),
          [(s["kind"], s["status"]) for s in d["segments"]])
    check("段落状态与核验门禁一致",
          all((s["status"] == S_SEG_BLOCKED) == any(g.get("blocking")
                                                    for g in s.get("gaps") or [])
              for s in d["segments"]),
          [(s["kind"], s["status"], [g.get("blocking") for g in s.get("gaps") or []])
           for s in d["segments"]])

    # 素材为空也必须出稿(模板占位), 不抛异常
    empty = eng.draft([], [], {"gaps": []}, window={"current": "2025-11"})
    check("无素材也降级出稿", len(empty["segments"]) >= 1, empty["segments"][:1])

    # 分句取料: 同一分句不会被两段复用(去重守卫)
    used = set()
    a = take_clause(mats[4], used)
    b = take_clause(mats[4], used)
    check("分句去重守卫", a and (b is None or b["clause_index"] != a["clause_index"]),
          (a, b))


# ---------- T2.3 ----------
def test_store_and_versions():
    print("[T2.3] content_store / content_versions")
    ts = TopicStore("stage2_store")
    ts.clear()
    r1 = ts.add({"kind": "no_draft", "subject": "编程马拉松比赛", "score": 3.0,
                 "gap_count": 6, "authority_mean": 0.8, "label": "素材多但无稿"})
    r2 = ts.add({"kind": "no_draft", "subject": "编程马拉松比赛", "score": 3.0,
                 "gap_count": 6, "authority_mean": 0.8})
    check("选题入库", r1["added"] is True)
    check("重复选题不重复入库", r2["added"] is False and r2["seen_count"] == 2, r2)
    ts.add({"kind": "thin_source", "subject": "迎新晚会报道", "score": 1.0,
            "gap_count": 2, "authority_mean": 0.6})
    check("选题库计数", ts.count() == 2, ts.count())

    first = ts.pop_next()
    second = ts.pop_next()
    third = ts.pop_next()
    check("轮询: 先取高分的那条", first["subject"] == "编程马拉松比赛", first)
    check("轮询: asked_count 递增并轮到另一条",
          second["subject"] == "迎新晚会报道" and third["subject"] == "编程马拉松比赛",
          (second["subject"], third["subject"]))
    check("exclude 去重守卫", ts.pop_next(exclude=[first["id"]]) is not None)
    check("选题库 File 兜底后端", ts.backend == "file", ts.backend)

    # 稿件版本: 版本号 = 图 seq
    draft = {"topic": "本届编程马拉松比赛", "segments": [
        {"seg_id": "seg_1", "kind": "lead", "label": "导语",
         "text": "11月20日在第三报告厅举办本届编程马拉松比赛。"}],
        "block": False}
    save_version("stage2_ver", 7, draft, track="base")
    save_version("stage2_ver", 9, draft, track="base")
    got = get_version("stage2_ver", 7)
    check("按 seq 取版本", got is not None and got["seq"] == 7, got)
    check("版本列表新→旧", [v["seq"] for v in versions("stage2_ver")][:2] == [9, 7],
          versions("stage2_ver"))
    check("版本含轨道标签", versions("stage2_ver")[0]["track_label"].startswith("轨一"),
          versions("stage2_ver")[0])
    check("稿件转文本", "导语" in draft_to_text(draft), draft_to_text(draft))


# ---------- T2.4 + A5 ----------
def _demo_draft():
    """跑一遍完整的编排链路(闸门 auto_deny → 零 LLM 轨一), 拿到真实稿件与平台版本。"""
    rt = ContentRuntime(base_dir=os.path.join(_TMP, "render_graphs"))
    club = "stage2_render"
    rt.seed_demo(club)
    rt.scan_topics(club)
    draft = rt.draft(club)["draft"]
    rt.verify(club, draft)
    pv = rt.platform_versions(club, draft, force=True)["platforms"]
    return rt, club, draft, pv


def test_render_and_a5():
    print("[T2.4 + A5] 双轨渲染 + 断言级 diff")
    rt, club, d, versions_ = _demo_draft()
    mats = rt.materials(club)
    check("三个平台版本", set(versions_.keys()) == {"wechat", "shortvideo", "poster"},
          list(versions_))
    check("订阅号不超字数", not versions_["wechat"]["limit"]["over"],
          versions_["wechat"]["limit"])
    check("海报不超字数", not versions_["poster"]["limit"]["over"],
          versions_["poster"]["limit"])
    check("短视频带 6 个分镜", len(versions_["shortvideo"]["shots"]) == 6,
          len(versions_["shortvideo"]["shots"]))
    check("平台规范段落映射生效",
          [s["kind"] for s in versions_["shortvideo"]["segments"]]
          == ["hook", "conflict", "proof", "cta"],
          [s["kind"] for s in versions_["shortvideo"]["segments"]])
    draft_refs = {s["seg_id"]: s.get("source_refs") or [] for s in d["segments"]}
    check("平台版本保留段落的来源指针(右栏同步高亮的前提)",
          all((s.get("source_refs") or []) == draft_refs.get(s.get("seg_id"), [])
              for s in versions_["wechat"]["segments"]),
          [(s.get("seg_id"), s.get("source_refs")) for s in versions_["wechat"]["segments"]])
    check("涉隐私素材不会被抄进稿件",
          all("13812345678" not in (s.get("text") or "")
              for s in versions_["wechat"]["segments"])
          and all("13812345678" not in (s.get("text") or "")
                  for s in d["segments"]),
          [s.get("text") for s in d["segments"]])
    check("字数上限来自 platform_spec",
          versions_["wechat"]["limit"]["limit"] == spec.PLATFORM_SPECS["wechat"]["max_chars"])

    pkg = export_package(versions_["wechat"]["text"], versions_, d["topic"])
    check("宣发包含三平台", all(v["label"] in pkg for v in versions_.values()),
          pkg[:80])

    # A5: 用一段**确定含数字与专名**的基线文本做断言级 diff
    base = ("11月20日, 本届编程马拉松比赛在第三报告厅举行, 实际到场183人, "
            "参赛队伍12支, 指导老师王老师做赛前动员。")
    good = ("11月20日, 本届编程马拉松比赛在第三报告厅如期举行, 到场人数为183人, "
            "共有12支参赛队伍, 指导老师王老师到场做赛前动员。")
    r_ok = assertion_diff(base, good)
    check("A5: 只改表达不改事实 → 通过", r_ok["ok"], r_ok["violations"])
    check("A5: 基线指纹含数字与专名",
          r_ok["base_fingerprint"]["numbers"] and r_ok["base_fingerprint"]["entities"],
          r_ok["base_fingerprint"])

    r_bad = assertion_diff(base, base.replace("183", "300"))
    check("A5: 改数字 → 判失败", not r_bad["ok"], r_bad["violations"])
    check("A5: 违规说明指出数字", any("数字" in v for v in r_bad["violations"]),
          r_bad["violations"])
    r_name = assertion_diff(base, base.replace("第三报告厅", "大学生活动中心"))
    check("A5: 改场地 → 判失败", not r_name["ok"], r_name["violations"])
    r_time = assertion_diff(base, base.replace("11月20日", "11月21日"))
    check("A5: 改时间 → 判失败", not r_time["ok"], r_time["violations"])
    r_add = assertion_diff(base, base + " 本次比赛反响热烈, 好评如潮。")
    check("A5: 新增无据表述 → 判失败", not r_add["ok"], r_add["violations"])
    r_drop = assertion_diff(base, base.replace("指导老师王老师做赛前动员", ""))
    check("A5: 删掉人名 → 判失败", not r_drop["ok"], r_drop["violations"])

    fp = assertion_set(base)
    check("断言指纹含四类槽位",
          all(k in fp for k in ("numbers", "entities", "periods", "subjective")), fp)
    check("指纹识别出数字/专名/时间",
          bool(fp["numbers"]) and bool(fp["entities"]) and bool(fp["periods"]), fp)


# ---------- A2 + 端到端 ----------
def test_end_to_end_and_a2():
    print("[A2] 端到端 + 回滚联动")
    rt = ContentRuntime(base_dir=os.path.join(_TMP, "e2e_graphs"))
    club = "stage2_e2e"
    seeded = rt.seed_demo(club)
    check("演示语料入库", seeded["count"] == len(corpus.all_materials()), seeded["count"])

    st = rt.store_for(club)
    head_after_seed = st.head_seq

    topics = rt.scan_topics(club)
    check("选题扫描有结果", len(topics["topics"]) >= 1, topics["topics"][:1])
    check("选题入选题库", topics["added"]["total"] >= 1, topics["added"])

    d1 = rt.draft(club)
    seq_draft = d1["seq"]
    check("成稿落 cites 边", len(st.latest()["edges"]["cites"]) >= 1,
          len(st.latest()["edges"]["cites"]))
    check("成稿登记步骤行",
          any(r.get("step") == "topic_draft" for r in rt.report_rows(club)),
          rt.report_rows(club)[:2])

    v = rt.verify(club)
    check("核验产出缺口与清单", "gaps" in v["verify"] and "check_list" in v,
          v["verify"]["summary"])
    pv = rt.platform_versions(club)
    if pv.get("blocked"):
        check("门禁拦住阻断稿件(符合 design/11 §5.5)", True)
        pv = rt.platform_versions(club, force=True)
    check("多平台版本产出", set(pv["platforms"].keys()) >= {"wechat", "shortvideo"},
          list(pv["platforms"].keys()))

    rec = rt.review_record(club)
    check("审核记录含素材/缺口/版本/LLM 用量",
          all(k in rec["record"] for k in ("materials", "gaps", "versions", "llm")),
          list(rec["record"].keys()))
    check("审核记录带免责声明(不做 AI 审核结论)",
          "审核结论由人作出" in rec["record"]["disclaimer"], rec["record"]["disclaimer"])

    # A2: 素材图回滚 → cites 边与稿件版本同步回退
    rb = rt.rollback(club, 3, reason="验收A2")
    check("A2: 素材图回滚成功", rb.get("rolled_back") is True, rb)
    check("A2: 回滚后 cites 边随日志一起回退",
          len(rt.store_for(club).latest()["edges"]["cites"]) == 0,
          rt.store_for(club).latest()["edges"]["cites"])
    check("A2: 回滚后素材数回到 seq=3 的状态",
          len(rt.materials(club)) == 3, len(rt.materials(club)))
    check("A2: 稿件按 seq 联动回看", "error" in rb["draft"] or rb["draft"].get("seq") == 3,
          rb["draft"])

    # 回滚后可继续工作(与 design/11 §9 A2 的"回退后再往前走")
    again = rt.draft(club)
    check("A2: 回滚后可重新成稿", len(again["draft"]["segments"]) >= 1,
          len(again["draft"]["segments"]))

    dash = rt.dashboard(club)
    check("仪表盘给出人机分工量化",
          "确定性操作" in dash["human_division"], dash["human_division"])
    check("仪表盘统计 LLM 分点计数", "by_point" in dash["llm"], dash["llm"])


def test_user_resolution():
    print("[裁决闭环] 矛盾由用户点选口径 → 重出稿件 → 裁决跨轮次有效")
    rt = ContentRuntime(base_dir=os.path.join(_TMP, "resolve_graphs"))
    club = "stage2_resolve"
    rt.seed_demo(club)
    rt.draft(club)
    cl = rt.detect_gaps(club)["check_list"]
    conf = [c for c in cl if c["weakness_type"] == CONFLICT]
    check("检出矛盾供用户裁决", len(conf) >= 1, [(c["assertion"]) for c in conf])
    chosen = conf[0]["candidates"][0]["eid"]     # 用户点「选它」
    out = rt.re_draft_with_resolution(club, chosen, seg_id=conf[0].get("seg_id") or "")
    check("裁决后重出稿件(版本前进)", out.get("seq", 0) > 0, out.get("seq"))
    check("重出的稿件状态被核验过",
          all(s["status"] in ("verified", "blocked") for s in out["segments"]),
          [(s["kind"], s["status"]) for s in out["segments"]])

    # 再核验一次: 用户裁决必须**跨核验轮次有效**(否则每次核验都会把同一矛盾摆回来)
    again = rt.detect_gaps(club)
    conf2 = [g for g in again["gaps"] if g["weakness_type"] == CONFLICT]
    check("裁决跨核验轮次有效(记录已落盘)", len(rt.topics_for(club).resolutions()) >= 1,
          rt.topics_for(club).resolutions())
    check("裁决结果是用户选的那一版(值取用户所选)",
          any(g.get("chosen_eid") == chosen for g in conf2),
          [(g.get("chosen_eid"), g.get("resolution")) for g in conf2])
    check("裁决后该矛盾不再是阻断项",
          all(not g.get("blocking") for g in conf2), [g.get("blocking") for g in conf2])
    check("其余矛盾仍按权威度给出裁定(不误标为用户裁决)",
          all(g.get("resolution") in ("user", "authority") for g in conf2),
          [g.get("resolution") for g in conf2])
    rec = rt.review_record(club)["record"]
    check("审核记录里留痕用户裁决",
          any(x.get("action") == "redraft_after_resolution" for x in rec["report_rows"])
          and bool(rec.get("resolutions")),
          [x.get("action") for x in rec["report_rows"]][:6])


def main():
    try:
        test_topic_gap()
        test_engine()
        test_store_and_versions()
        test_render_and_a5()
        test_end_to_end_and_a2()
        test_user_resolution()
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
    if FAILS:
        print("\n阶段2 发布相测试 FAILED: %d 项" % len(FAILS))
        raise SystemExit(1)
    print("\n阶段2 发布相测试 PASSED")


if __name__ == "__main__":
    main()
