# coding: utf-8
"""_test_workbench_flow.py — 三栏工作台的端到端验收(HTTP 层, 零 LLM)。

覆盖:
1. GET /workbench → 200, 且 `__AUTH_TOKEN__` 已被 server.py 换成真令牌, 页面引用的
   三个静态资源(GET /static/...)全部 200;
2. 带 X-Auth-Token 头走完六步: seed_demo → gaps/checklist → topics → draft → verify
   → platforms, 并校验前端要用到的关键字段都在(段 status / limit.over / shots=6 /
   待核实清单的 candidates 两个候选 / 矛盾裁决入口);
3. 矛盾裁决(resolve_conflict)→ 重新成稿核验; 回滚(rollback)后稿件版本同步回退;
4. 令牌校验: 不带 X-Auth-Token 的 /api/content/state 必须 401(前端必须带头)。
"""
import json
import os
import shutil
import sys
import uuid

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["EMBEDDING_OFF"] = "1"
os.environ["LLM_GATE_MODE"] = "auto_deny"
os.environ["TOPIC_STORE_BACKEND"] = "file"
os.environ["AUTH_TOKEN"] = "workbench-test-token"     # 固定令牌, 便于断言注入
os.environ.pop("AUTH_ENABLED", None)
_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_TMP = os.path.join(_HERE, "data", "_test_workbench_tmp")
shutil.rmtree(_TMP, ignore_errors=True)
os.environ["STORAGE_BASE_DIR"] = os.path.join(_TMP, "graphs")
os.environ["CONTENT_VERSIONS_DIR"] = os.path.join(_TMP, "versions")
os.environ["TOPIC_BANK_DIR"] = os.path.join(_TMP, "topics")
os.environ["REPORT_DIR"] = os.path.join(_TMP, "reports")
# 用户裁决是**跨核验轮次**落盘的(data/resolutions/, 这是"用户说过的口径永远优先"的
# 实现)。测试必须也把它关进临时目录, 否则第二次跑同一脚本时, 上一轮留下的裁决会让
# "用户覆盖系统先裁定"这类断言失效(裁决已经存在, 系统当然照它办)。
os.environ["RESOLUTION_DIR"] = os.path.join(_TMP, "resolutions")
# LLM 审计日志同样要隔离: "零 LLM 下没有一次成功调用"这条断言依赖这份日志从 0 起算。
# 不隔离的话, 谁在开发机上真实跑过一次团队复盘, 这条断言就会假失败(踩过)。
os.environ["LLM_GATE_LOG"] = os.path.join(_TMP, "llm_gate.jsonl")

from starlette.testclient import TestClient  # noqa: E402

import server  # noqa: E402

C = TestClient(server.app)
# 每次运行用独立社团 id: 素材图/版本/选题库虽然都在临时目录里, 但 Windows 上临时目录
# 偶发删不掉, 于是"重跑时把演示语料灌第二遍"会让断言漂移(材料翻倍 → 缺口类型与选题
# 数都变)。换 id 就能保证每次跑的起点一致, 也让脚本可重复运行。
CLUB = os.getenv("WB_TEST_CLUB") or ("demo_club_" + uuid.uuid4().hex[:6])
TOKEN = {"X-Auth-Token": "workbench-test-token"}
FAILS = []


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s  %s" % (name, detail))
        FAILS.append(name)


def main():
    print("[1] 页面与静态资源")
    r = C.get("/workbench")
    check("/workbench 200", r.status_code == 200, r.status_code)
    check("页面内注入真令牌", "workbench-test-token" in r.text and "__AUTH_TOKEN__" not in r.text)
    check("页面引 tokens.css / workbench.css / workbench.js(不再依赖旧 style.css)",
          all(x in r.text for x in ("static/tokens.css", "static/workbench.css",
                                    "static/workbench.js"))
          and "static/style.css" not in r.text)
    for res in ("tokens.css", "workbench.css", "workbench.js"):
        rr = C.get("/static/" + res)
        check("/static/%s 200" % res, rr.status_code == 200, rr.status_code)
    # 退休的旧界面: 首页直接给工作台, 旧静态文件 404
    check("首页就是工作台(不再有第二套 UI)",
          "采编台" in C.get("/").text and "/workbench" in C.get("/").text)
    check("旧版界面静态文件已下线",
          C.get("/static/index.html").status_code == 404
          and C.get("/static/app.js").status_code == 404
          and C.get("/static/review.js").status_code == 404)
    check("旧复盘页跳回工作台",
          C.get("/review", follow_redirects=False).status_code in (301, 302, 307, 308))

    print("[2] 令牌校验(前端必须带 X-Auth-Token 头)")
    check("无令牌 → 401", C.get("/api/content/state", params={"club_id": CLUB}).status_code == 401)
    check("带令牌 → 200",
          C.get("/api/content/state", params={"club_id": CLUB}, headers=TOKEN).status_code == 200)

    print("[3] 六步链路(HTTP, 零 LLM)")
    seed = C.post("/api/content/seed_demo", json={"club_id": CLUB}, headers=TOKEN).json()
    check("① seed_demo 入库 11 条", seed.get("count") == 11, seed.get("count"))
    st = C.get("/api/content/state", params={"club_id": CLUB}, headers=TOKEN).json()
    check("state 带 badge.band(权威度五档)", all("badge" in m and m["badge"].get("band")
                                                for m in st["materials"]))
    bands = sorted({m["badge"]["band"] for m in st["materials"]})
    check("五档里至少出现 official/organizer/on_site/member/hearsay 中的 4 档",
          len(bands) >= 4, bands)
    check("state 带 workflow.steps(六步)",
          st["workflow"]["steps"][:3] == ["material_intake", "gap_detect", "topic_draft"],
          st["workflow"]["steps"])

    gaps = C.get("/api/content/gaps", params={"club_id": CLUB}, headers=TOKEN).json()
    types = {g["weakness_type"] for g in gaps["check_list"]}
    check("② 缺口检测出五类里的多类", {"conflict", "sensitive", "isolated", "stale"} <= types, types)
    conf = [g for g in gaps["check_list"] if g["weakness_type"] == "conflict"]
    check("矛盾项带两个并列候选(前端并列展示)",
          conf and all(len(c.get("candidates") or []) >= 2 for c in conf), conf[:1])
    check("清单每条都能指回素材/段落",
          all(("source_eid" in g) and ("seg_id" in g) and g.get("label") for g in gaps["check_list"]))

    topics = C.get("/api/content/topics", params={"club_id": CLUB, "scan": 1},
                   headers=TOKEN).json()
    check("③ 选题扫描有结果", len(topics.get("topics") or []) >= 1, topics.get("topics"))
    bank = C.get("/api/content/topics", params={"club_id": CLUB, "scan": 0},
                 headers=TOKEN).json()
    check("③ 选题库后端为 file 兜底", bank.get("backend") == "file", bank.get("backend"))

    d = C.post("/api/content/draft", json={"club_id": CLUB, "max_segments": 6},
               headers=TOKEN).json()
    segs = d["draft"]["segments"]
    check("③ 成稿 6 段且每段带 status/source_refs",
          len(segs) == 6 and all(s.get("status") and "source_refs" in s for s in segs),
          [(s.get("label"), s.get("status")) for s in segs])
    check("③ 零 LLM(LLM 段 0)", d["degraded"]["llm_segments"] == 0, d["degraded"])

    v = C.post("/api/content/verify", json={"club_id": CLUB}, headers=TOKEN).json()
    check("④ 核验逐段给断言与状态",
          len(v["verify"]["segments"]) == 6 and all("claims" in s for s in v["verify"]["segments"]))
    check("④ 核验返回 check_list 与 block 标记",
          "check_list" in v and "block" in v, list(v))

    # ④' 核验"用户拖拽组装出来的稿"：工作台把组装结果作为 segments 提交，
    # 后端必须在**这一份**稿上跑断言溯源，而不是拿库里已保存的那版核验。
    # 这里就用手上这 6 段（真实场景是用户拖着改过的同一份结构）。
    hand = [{"seg_id": s["seg_id"], "kind": s["kind"], "label": s.get("label") or "",
             "text": s["text"], "source_refs": list(s.get("source_refs") or [])}
            for s in segs[:3]]
    hand.append({"seg_id": "seg_hand_x", "kind": "highlight", "label": "亮点",
                 "text": "到场200人。", "source_refs": ["evt_000004"]})
    v2 = C.post("/api/content/verify",
                json={"club_id": CLUB, "segments": hand}, headers=TOKEN).json()
    check("④ 核验收下人工组装的段落(按提交的那份核验)",
          len(v2["verify"]["segments"]) == 4, len(v2["verify"]["segments"]))
    check("④ 人工稿的断言被逐条核验(含数字断言)",
          any(c.get("kind") == "metric"
              for s in v2["verify"]["segments"] for c in (s.get("claims") or [])),
          [c.get("kind") for s in v2["verify"]["segments"] for c in (s.get("claims") or [])])
    check("④ 人工稿同样过门禁(block 为布尔)",
          isinstance(v2["block"], bool), v2["block"])
    ver2 = C.get("/api/content/versions", params={"club_id": CLUB}, headers=TOKEN).json()
    tracks2 = [v["track"] for v in ver2["versions"]]
    check("④ 组装稿落组装轨、不动系统成稿的轨一基线",
          "compose" in tracks2 and "base" in tracks2, tracks2)
    check("④ 组装稿随 versions 返回给前端恢复(compose 字段)",
          len((ver2.get("compose") or {}).get("segments") or []) == 4,
          len((ver2.get("compose") or {}).get("segments") or []))
    check("④ current 仍是轨一基线(平台渲染与回滚认它)",
          (ver2.get("current") or {}).get("track") in ("base", None),
          (ver2.get("current") or {}).get("track"))

    pf = C.post("/api/content/platforms", json={"club_id": CLUB}, headers=TOKEN).json()
    if pf.get("blocked"):
        check("⑤ 有阻断项时被拦下并给理由", bool(pf.get("reason")) and "gaps" in pf, pf.get("reason"))
        pf = C.post("/api/content/platforms", json={"club_id": CLUB, "force": True},
                    headers=TOKEN).json()
    P = pf["platforms"]
    check("⑤ 三平台齐全", set(P) == {"wechat", "shortvideo", "poster"}, list(P))
    check("⑤ 订阅号六段 lead..closing",
          [s["kind"] for s in P["wechat"]["segments"]]
          == ["lead", "background", "process", "highlight", "impact", "closing"],
          [s["kind"] for s in P["wechat"]["segments"]])
    check("⑤ 短视频 4 段 + 6 分镜",
          [s["kind"] for s in P["shortvideo"]["segments"]] == ["hook", "conflict", "proof", "cta"]
          and len(P["shortvideo"]["shots"]) == 6,
          [s["kind"] for s in P["shortvideo"]["segments"]])
    check("⑤ 每平台带 limit.count/limit/over",
          all(set(["count", "limit", "over"]) <= set(p["limit"]) for p in P.values()))
    check("⑤ 平台段带 source_refs(右栏同步高亮的前提)",
          all("source_refs" in s for s in P["wechat"]["segments"]))
    check("⑤ 海报不超 60 字", not P["poster"]["limit"]["over"], P["poster"]["limit"])

    print("[4] 版本下拉 / 回滚出口 / 导出")
    ver = C.get("/api/content/versions", params={"club_id": CLUB}, headers=TOKEN).json()
    check("版本列表非空且只含稿件轨道(不含平台变体)",
          ver["versions"] and all(v0["track"] in ("base", "polished", "compose")
                                    for v0 in ver["versions"]),
          [(v0["seq"], v0["track"]) for v0 in ver["versions"]])
    check("current 是六段稿件(不是某个平台版)",
          len(ver["current"]["segments"]) == 6, len(ver["current"]["segments"]))
    check("当前稿件随首次加载恢复: current 也是稿件基线",
          [s.get("kind") for s in ver["current"]["segments"]]
          == ["lead", "background", "process", "highlight", "impact", "closing"],
          [s.get("kind") for s in ver["current"]["segments"]])
    seq0 = ver["versions"][-1]["seq"]
    one = C.get("/api/content/versions", params={"club_id": CLUB, "seq": seq0},
                headers=TOKEN).json()
    check("按 seq 取版本可用", one.get("seq") == seq0 and "segments" in one, one.get("seq"))
    rb = C.post("/api/content/rollback",
                json={"club_id": CLUB, "to_seq": seq0, "reason": "acceptance"},
                headers=TOKEN).json()
    check("回滚返回 rolled_back + head_seq", "rolled_back" in rb and "head_seq" in rb, rb.get("error"))
    check("导出《审核记录》", C.get("/api/content/review_export", params={"club_id": CLUB},
                              headers=TOKEN).status_code == 200)
    check("导出「宣发包」", C.get("/api/content/export_package", params={"club_id": CLUB},
                              headers=TOKEN).status_code == 200)

    print("[5] 素材录入(analyze → ingest) 与仪表盘")
    an = C.post("/api/content/analyze",
                json={"club_id": CLUB, "text": "本次比赛反响热烈，到场人数超过300人。"},
                headers=TOKEN).json()
    check("analyze 逐句返回 verdict（含 kind/reason）",
          an["items"] and all({"kind", "reason"} <= set(i["verdict"]) for i in an["items"]),
          an["items"][:1])
    ig = C.post("/api/content/ingest",
                json={"club_id": CLUB, "materials": [
                    {"content": "补录: 签到志愿者共 12 人到场。", "source": "organizer"}]},
                headers=TOKEN).json()
    check("ingest 返回 eid/authority", ig["imported"] and ig["imported"][0].get("authority") == 0.85,
          ig["imported"])
    dash = C.get("/api/content/dashboard", params={"club_id": CLUB}, headers=TOKEN).json()
    check("仪表盘有「确定性操作 / LLM 调用」分工数字",
          "deterministic_ops" in dash and "human_division" in dash, dash.get("human_division"))
    # 零 LLM 的正确口径: **没有一次调用成功**(ok=0); 被闸门拦下的尝试也会留审计行,
    # 那些恰好证明闸门在工作(授权点必须用户点授权, auto_deny 下连默认点也不放行)。
    ok_calls = sum(int(v.get("ok") or 0) for v in (dash["llm"].get("by_point") or {}).values())
    check("零 LLM 下没有任何一次 LLM 调用成功", ok_calls == 0, dash["llm"])
    gate_rows = sum(int(v.get("error") or 0) for v in (dash["llm"].get("by_point") or {}).values())
    check("被拦下的尝试全部留了审计行(闸门可核查)",
          gate_rows == int(dash["llm"]["default"]) + int(dash["llm"]["authorized"]),
          dash["llm"])

    print("[6] 矛盾由用户裁决(resolve_conflict) — 裁决闭环")
    check("裁决前清单已给出按权威度的先裁定", bool(conf[0].get("resolution")),
          {k: conf[0].get(k) for k in ("resolution", "chosen_eid", "resolved")})
    # 现取当前清单: 上一节录入的素材可能改了这条矛盾的候选, 所以这里按最新状态选
    # **权威度较低**的那一版(否则等于选了系统本来就会选的那版, 测不出"用户覆盖")。
    fresh = C.get("/api/content/checklist", params={"club_id": CLUB},
                  headers=TOKEN).json()["check_list"]
    conf_now = [c for c in fresh if c["weakness_type"] == "conflict"
                and c.get("candidates")][0]
    picked = sorted(conf_now["candidates"], key=lambda c: float(c.get("authority") or 0))[0]
    check("选中的是权威度较低的那一版(用户覆盖系统先裁定)",
          picked["eid"] != conf_now.get("chosen_eid"),
          (picked["eid"], conf_now.get("chosen_eid")))
    rec = C.post("/api/content/resolve_conflict",
                 json={"club_id": CLUB, "chosen_eid": picked["eid"],
                       "seg_id": conf_now.get("seg_id") or ""}, headers=TOKEN).json()
    check("裁决被记录(chosen_eid/chosen_text)", rec.get("resolved") and rec.get("chosen_text"),
          rec)
    rd = rec.get("redraft") or {}
    check("裁决返回 redraft(seq/resolution_key/segments/block/gaps_by_type)",
          {"seq", "resolution_key", "segments", "block", "gaps_by_type"} <= set(rd),
          sorted(rd))
    check("redraft 当场重出一稿且段带 status",
          rd.get("segments") and all(s.get("status") for s in rd["segments"]),
          [(s.get("seg_id"), s.get("status")) for s in (rd.get("segments") or [])])
    cl2 = C.get("/api/content/checklist", params={"club_id": CLUB}, headers=TOKEN).json()
    got = [c for c in cl2["check_list"]
           if c["weakness_type"] == "conflict" and c.get("chosen_eid") == picked["eid"]]
    check("裁决后清单把该矛盾标成 user 选定 + 带 resolution_note",
          got and got[0].get("resolution") == "user" and got[0].get("resolution_note"),
          got[:1])
    check("裁决后两个候选仍并列(另一版可改选)", got and len(got[0]["candidates"]) >= 2,
          got[:1])
    # 裁决后稿件重出 → 平台适配要么放行、要么被阻断项拦下(拦下也是正确行为, 见
    # design/11 §5.5 门禁); 两种结果都必须给出明确字段, 不许"什么都没有"。
    pc = C.post("/api/content/platforms", json={"club_id": CLUB}, headers=TOKEN).json()
    if pc.get("blocked"):
        check("裁决后适配被阻断项拦下(给理由与阻断清单)",
              bool(pc.get("reason")) and isinstance(pc.get("gaps"), list), pc.get("reason"))
        check("拦下是门禁而非报错", "error" not in pc, pc.get("error"))
    else:
        check("裁决后仍能出多平台版(没有阻断项时)", pc.get("blocked") is False,
              pc.get("reason"))
        check("裁决后适配给的是三平台版本",
              set(pc.get("platforms") or {}) == {"wechat", "shortvideo", "poster"},
              list(pc.get("platforms") or {}))
    after = C.get("/api/content/versions", params={"club_id": CLUB}, headers=TOKEN).json()
    check("裁决重出后 current 仍是稿件基线(不是平台变体)",
          [s.get("kind") for s in after["current"]["segments"]]
          == ["lead", "background", "process", "highlight", "impact", "closing"],
          [s.get("kind") for s in after["current"]["segments"]])
    rr = C.get("/api/content/review_record", params={"club_id": CLUB}, headers=TOKEN).json()
    actions = [x.get("action") for x in rr["record"]["steps"]]
    check("审核记录里留痕 user_resolve_conflict", "user_resolve_conflict" in actions, actions[-6:])
    check("审核记录里留痕 redraft_after_resolution(裁决后重出也留痕)",
          "redraft_after_resolution" in actions, actions[-6:])
    print("")
    if FAILS:
        print("FAILED(%d): %s" % (len(FAILS), "; ".join(FAILS)))
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
