﻿# design/ — 方案文档索引（交付物）

| 文档 | 内容 |
| --- | --- |
| **[11_内容域改造方案.md](11_内容域改造方案.md)** | **本项目改造依据（先读这份）**：六步两相、断言级核验、缺口五类、双轨渲染与断言级 diff、六个角色、验收标准 A1/A2/A3/A5、风险与砍单顺序 |
| 本文件 | 索引 |

## 交付物里的设计文档就这两份

面试域的历史设计（事件模型、日志与快照回滚、逐句裁决、Mongo 存储、接口、LLM 闸门、
出题引擎 v3、总体架构、复盘智能体、一体化复盘）已经移到上层 `legacy/design/01`–`10`。
方案 11 里对它们的引用仍然有效——那是"我们从什么改造过来"的记录。

## 落地位置速查（方案 → 代码）

| 方案里的章节 | 落在哪 |
| --- | --- |
| §4 素材图与权威度 | `graphstore/`、`content/material_ops.py`、`content/material_analyst.py` |
| §5.1 断言抽取 | `content/material_ops.py` |
| §5.2 五类缺口 | `content/fact_verifier.py` |
| §5.3 成稿决策链 | `content/content_engine.py` |
| §5.4 双轨渲染 + 断言级 diff | `content/render.py`、`content/platform_spec.py` |
| §5.4' 三渠道实时预览 | `content/preview.py`（无门禁，拖一下就重算） |
| §5.5 六步两相 | `content/workflow.py`、`content/content_runtime.py` |
| §7 三列工作台 | `static/workbench.*`、`static/doc-board.js` |
| §9 T3.1 六角色 | `components/review_runtime.py`（团队路线）、`content/assist.py`（确定性路线） |
| §9 T3.2 领域工具 | `components/content_tools.py` |
| §6 LLM 闸门与审计 | `components/llm_gate.py`、`components/llm_gate_team.py` |
| §12 验收 A1/A2/A3/A5 | `test/_test_stage*.py`、`tools/check_acceptance.py` |
